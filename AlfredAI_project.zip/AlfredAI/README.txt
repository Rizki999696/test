ALFRED AI v2.6.0 - PROJECT ANDROID STUDIO / GITHUB ACTIONS

BUILD LEWAT GITHUB (dari HP)
1. Ganti file AlfredAI_project.zip di repo dengan yang baru (Add file > Upload files, nama sama).
2. Actions > Build APK > Run workflow (build.yml tidak perlu diganti).
3. Unduh artifact AlfredAI-apk, ekstrak, hapus aplikasi lama, pasang app-debug.apk.
4. Aktifkan lagi Aksesibilitas Alfred AI (izin baru ditambahkan).

UKURAN PANEL
OverlayService.java: PANEL_SCALE = 1.4f

FITUR UTAMA v2.6
- 3000 fitur offline (17 kategori, 176-177 per kategori), pencarian dan halaman per 60.
- Tab Aplikasi: semua aplikasi di HP + pencarian; web (YouTube, WhatsApp, dll) dibuka di dalam bulatan.
- Tab Kontrol: pengaturan cepat, statistik, jaringan, VPN & ping game.
- Menu VPN & Jaringan juga ada di aplikasi utama (panel galaxy).
- AI: jawaban inti dikutip dan ditebalkan, fakta terverifikasi lokal, streaming, Enter = baris baru.
- Keyboard: ketuk kotak ketik selalu memunculkan keyboard.

CATATAN JUJUR
- Alfred bukan layanan VPN dan tidak punya server VPN.
- Tidak ada aplikasi yang bisa menjamin ping 1 ms.
