package com.alfredai.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

final class Notifier {
    static final String CHANNEL = "alfred_notifs";

    private Notifier() {}

    static void ensureChannel(Context c) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null && nm.getNotificationChannel(CHANNEL) == null) {
                NotificationChannel ch = new NotificationChannel(
                        CHANNEL, "Notifikasi Alfred AI", NotificationManager.IMPORTANCE_DEFAULT);
                ch.setDescription("Notifikasi harian Alfred AI");
                nm.createNotificationChannel(ch);
            }
        }
    }

    static void show(Context c, String title, String body, int id) {
        try {
            ensureChannel(c);
            if (title == null) title = "Alfred AI";
            if (body == null) body = "";
            Intent open = new Intent(c, MainActivity.class);
            open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            PendingIntent pi = PendingIntent.getActivity(
                    c, id, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            Notification.Builder b;
            if (Build.VERSION.SDK_INT >= 26) {
                b = new Notification.Builder(c, CHANNEL);
            } else {
                b = new Notification.Builder(c);
                b.setPriority(Notification.PRIORITY_DEFAULT);
            }
            b.setSmallIcon(R.drawable.stat_galaxy)
                    .setContentTitle(title)
                    .setContentText(body)
                    .setStyle(new Notification.BigTextStyle().bigText(body))
                    .setContentIntent(pi)
                    .setAutoCancel(true);
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(id, b.build());
        } catch (Exception ignored) {
            // tanpa izin notifikasi: abaikan saja
        }
    }
}
