package com.alfredai.app;

import android.app.ActivityManager;
import android.app.NotificationManager;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.location.LocationManager;
import android.media.AudioManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.TrafficStats;
import android.net.Uri;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.StatFs;
import android.os.SystemClock;
import android.provider.Settings;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.List;

/**
 * Alat sistem yang dipakai bersama oleh bulatan galaxy dan aplikasi utama.
 * Hanya memakai API resmi Android (tanpa root). Hal yang tidak boleh diubah langsung oleh aplikasi
 * (Wi-Fi, data seluler, Bluetooth, mode pesawat) dibuka lewat panel pengaturan resmi sistem.
 */
final class SysTools {

    static volatile Boolean torchOn = null;
    private static boolean torchReg = false;

    interface Cb {
        void done(String json);
    }

    private SysTools() {
    }

    private static long readLong(String path) {
        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader(path));
            String l = br.readLine();
            return l == null ? -1 : Long.parseLong(l.trim());
        } catch (Throwable t) {
            return -1;
        } finally {
            try {
                if (br != null) br.close();
            } catch (Throwable ignored) {
            }
        }
    }

    // ------------------------------------------------------------ statistik

    static String sysJson(Context c) {
        JSONObject o = new JSONObject();
        try {
            JSONObject bat = new JSONObject();
            try {
                Intent b = c.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
                if (b != null) {
                    int level = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                    int scale = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
                    bat.put("pct", scale > 0 ? level * 100 / scale : -1);
                    int st = b.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
                    bat.put("charging", st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL);
                    bat.put("temp", b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10.0);
                    bat.put("volt", b.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0));
                }
            } catch (Throwable ignored) {
            }
            o.put("bat", bat);

            JSONObject mem = new JSONObject();
            try {
                ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
                ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
                am.getMemoryInfo(mi);
                mem.put("total", mi.totalMem);
                mem.put("avail", mi.availMem);
                mem.put("low", mi.lowMemory);
            } catch (Throwable ignored) {
            }
            try {
                StatFs sf = new StatFs(Environment.getDataDirectory().getPath());
                mem.put("sTotal", sf.getTotalBytes());
                mem.put("sFree", sf.getAvailableBytes());
            } catch (Throwable ignored) {
            }
            o.put("mem", mem);

            JSONObject net = new JSONObject();
            try {
                ConnectivityManager cm = (ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE);
                Network an = cm.getActiveNetwork();
                NetworkCapabilities nc = an == null ? null : cm.getNetworkCapabilities(an);
                net.put("wifi", nc != null && nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI));
                net.put("cell", nc != null && nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR));
                net.put("online", nc != null && nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET));
                net.put("down", nc == null ? 0 : nc.getLinkDownstreamBandwidthKbps());
                net.put("up", nc == null ? 0 : nc.getLinkUpstreamBandwidthKbps());
                net.put("vpn", vpnActive(c));
            } catch (Throwable ignored) {
            }
            try {
                WifiManager wm = (WifiManager) c.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                net.put("wifiOn", wm.isWifiEnabled());
                WifiInfo wi = wm.getConnectionInfo();
                if (wi != null) {
                    int rssi = wi.getRssi();
                    net.put("rssi", rssi);
                    net.put("link", wi.getLinkSpeed());
                    net.put("lvl", rssi >= -55 ? 4 : rssi >= -65 ? 3 : rssi >= -75 ? 2 : rssi >= -85 ? 1 : 0);
                    net.put("freq", wi.getFrequency());
                }
            } catch (Throwable ignored) {
            }
            try {
                net.put("rx", TrafficStats.getTotalRxBytes());
                net.put("tx", TrafficStats.getTotalTxBytes());
                net.put("t", SystemClock.elapsedRealtime());
            } catch (Throwable ignored) {
            }
            o.put("net", net);

            JSONObject cpu = new JSONObject();
            try {
                int n = Runtime.getRuntime().availableProcessors();
                cpu.put("cores", n);
                JSONArray cur = new JSONArray();
                JSONArray max = new JSONArray();
                boolean any = false;
                for (int i = 0; i < n; i++) {
                    long f = readLong("/sys/devices/system/cpu/cpu" + i + "/cpufreq/scaling_cur_freq");
                    long m = readLong("/sys/devices/system/cpu/cpu" + i + "/cpufreq/cpuinfo_max_freq");
                    if (f > 0) any = true;
                    cur.put(f);
                    max.put(m);
                }
                cpu.put("cur", cur);
                cpu.put("max", max);
                cpu.put("freqOk", any);
                cpu.put("hw", Build.HARDWARE);
                cpu.put("abi", Build.SUPPORTED_ABIS != null && Build.SUPPORTED_ABIS.length > 0 ? Build.SUPPORTED_ABIS[0] : "");
                if (Build.VERSION.SDK_INT >= 31) cpu.put("soc", Build.SOC_MODEL);
                long t = readLong("/sys/class/thermal/thermal_zone0/temp");
                if (t > 0) cpu.put("temp", t > 1000 ? t / 1000.0 : (double) t);
            } catch (Throwable ignored) {
            }
            o.put("cpu", cpu);

            JSONObject dev = new JSONObject();
            dev.put("model", Build.MANUFACTURER + " " + Build.MODEL);
            dev.put("android", Build.VERSION.RELEASE);
            dev.put("sdk", Build.VERSION.SDK_INT);
            dev.put("up", SystemClock.elapsedRealtime());
            o.put("dev", dev);

            JSONObject ctl = new JSONObject();
            ContentResolver cr = c.getContentResolver();
            try {
                ctl.put("bright", Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, -1));
                ctl.put("auto", Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, 0) == 1);
                ctl.put("rot", Settings.System.getInt(cr, Settings.System.ACCELEROMETER_ROTATION, 0) == 1);
                ctl.put("timeout", Settings.System.getInt(cr, Settings.System.SCREEN_OFF_TIMEOUT, 0));
                ctl.put("canWrite", Settings.System.canWrite(c));
            } catch (Throwable ignored) {
            }
            try {
                ctl.put("airplane", Settings.Global.getInt(cr, Settings.Global.AIRPLANE_MODE_ON, 0) == 1);
            } catch (Throwable ignored) {
            }
            try {
                AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
                JSONObject vol = new JSONObject();
                int[] ids = {AudioManager.STREAM_MUSIC, AudioManager.STREAM_RING, AudioManager.STREAM_ALARM,
                        AudioManager.STREAM_NOTIFICATION, AudioManager.STREAM_VOICE_CALL, AudioManager.STREAM_SYSTEM};
                String[] nm = {"music", "ring", "alarm", "notif", "voice", "system"};
                for (int i = 0; i < ids.length; i++) {
                    JSONObject s = new JSONObject();
                    s.put("v", am.getStreamVolume(ids[i]));
                    s.put("m", am.getStreamMaxVolume(ids[i]));
                    vol.put(nm[i], s);
                }
                ctl.put("vol", vol);
                ctl.put("ringer", am.getRingerMode());
            } catch (Throwable ignored) {
            }
            try {
                NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
                ctl.put("dnd", nm.getCurrentInterruptionFilter());
            } catch (Throwable ignored) {
            }
            try {
                ctl.put("saver", ((PowerManager) c.getSystemService(Context.POWER_SERVICE)).isPowerSaveMode());
            } catch (Throwable ignored) {
            }
            try {
                LocationManager lm = (LocationManager) c.getSystemService(Context.LOCATION_SERVICE);
                ctl.put("loc", Build.VERSION.SDK_INT >= 28 ? lm.isLocationEnabled() : true);
            } catch (Throwable ignored) {
            }
            try {
                android.bluetooth.BluetoothAdapter ba = android.bluetooth.BluetoothAdapter.getDefaultAdapter();
                ctl.put("bt", ba == null ? -1 : (ba.isEnabled() ? 1 : 0));
            } catch (Throwable t) {
                ctl.put("bt", -1);
            }
            ctl.put("torch", torchOn != null && torchOn);
            o.put("ctl", ctl);
        } catch (Throwable ignored) {
        }
        return o.toString();
    }

    // ------------------------------------------------------------ VPN

    static boolean vpnActive(Context c) {
        try {
            ConnectivityManager cm = (ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE);
            Network[] ns = cm.getAllNetworks();
            for (int i = 0; i < ns.length; i++) {
                NetworkCapabilities nc = cm.getNetworkCapabilities(ns[i]);
                if (nc != null && nc.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) return true;
            }
        } catch (Throwable ignored) {
        }
        return false;
    }

    private static final String[][] VPN_KNOWN = {
            {"OpenVPN Connect", "net.openvpn.openvpn"},
            {"Cloudflare 1.1.1.1 / WARP", "com.cloudflare.onedotonedotonedotone"},
            {"WireGuard", "com.wireguard.android"},
            {"Proton VPN", "ch.protonvpn.android"},
            {"NordVPN", "com.nordvpn.android"},
            {"ExpressVPN", "com.expressvpn.vpn"},
            {"Surfshark", "com.surfshark.vpnclient.android"},
            {"Windscribe", "com.windscribe.vpn"},
            {"TunnelBear", "com.tunnelbear.android"},
            {"Psiphon", "com.psiphon3"},
            {"Hotspot Shield", "hotspotshield.android.vpn"},
            {"Turbo VPN", "free.vpn.unblock.proxy.turbovpn"},
            {"Mullvad VPN", "net.mullvad.mullvadvpn"},
            {"Outline", "org.outline.android.client"},
            {"NextDNS", "io.nextdns.nextdns"}
    };

    static String vpnJson(Context c) {
        JSONObject o = new JSONObject();
        try {
            o.put("active", vpnActive(c));
            JSONArray apps = new JSONArray();
            PackageManager pm = c.getPackageManager();
            java.util.HashSet<String> seen = new java.util.HashSet<String>();
            for (int i = 0; i < VPN_KNOWN.length; i++) {
                try {
                    if (pm.getLaunchIntentForPackage(VPN_KNOWN[i][1]) != null) {
                        JSONObject a = new JSONObject();
                        a.put("p", VPN_KNOWN[i][1]);
                        a.put("n", VPN_KNOWN[i][0]);
                        apps.put(a);
                        seen.add(VPN_KNOWN[i][1]);
                    }
                } catch (Throwable ignored) {
                }
            }
            try {
                Intent main = new Intent(Intent.ACTION_MAIN);
                main.addCategory(Intent.CATEGORY_LAUNCHER);
                List<ResolveInfo> list = pm.queryIntentActivities(main, 0);
                for (int i = 0; i < list.size(); i++) {
                    ResolveInfo ri = list.get(i);
                    String pkg = ri.activityInfo.packageName;
                    CharSequence l = ri.loadLabel(pm);
                    String lab = l == null ? "" : l.toString();
                    if (!seen.contains(pkg) && (lab.toLowerCase().contains("vpn") || pkg.toLowerCase().contains("vpn"))) {
                        JSONObject a = new JSONObject();
                        a.put("p", pkg);
                        a.put("n", lab);
                        apps.put(a);
                        seen.add(pkg);
                    }
                }
            } catch (Throwable ignored) {
            }
            o.put("apps", apps);
        } catch (Throwable ignored) {
        }
        return o.toString();
    }

    // ------------------------------------------------------------ ping (RTT TCP)

    static void ping(final String host, final int port, final int count, final Cb cb) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                JSONObject o = new JSONObject();
                try {
                    o.put("host", host);
                    o.put("port", port);
                    InetAddress addr = InetAddress.getByName(host);
                    o.put("ip", addr.getHostAddress());
                    int n = Math.max(1, Math.min(count, 30));
                    double[] r = new double[n];
                    int ok = 0;
                    JSONArray arr = new JSONArray();
                    for (int i = 0; i < n; i++) {
                        long t0 = System.nanoTime();
                        Socket s = new Socket();
                        try {
                            s.connect(new InetSocketAddress(addr, port), 2500);
                            double ms = (System.nanoTime() - t0) / 1e6;
                            r[ok++] = ms;
                            arr.put(Math.round(ms * 10) / 10.0);
                        } catch (Throwable t) {
                            arr.put(-1);
                        } finally {
                            try {
                                s.close();
                            } catch (Throwable ignored) {
                            }
                        }
                        try {
                            Thread.sleep(120);
                        } catch (InterruptedException ignored) {
                        }
                    }
                    o.put("n", n);
                    o.put("ok", ok);
                    o.put("loss", n - ok);
                    o.put("rtts", arr);
                    if (ok > 0) {
                        double mn = 1e9, mx = 0, sum = 0, jit = 0;
                        for (int i = 0; i < ok; i++) {
                            mn = Math.min(mn, r[i]);
                            mx = Math.max(mx, r[i]);
                            sum += r[i];
                            if (i > 0) jit += Math.abs(r[i] - r[i - 1]);
                        }
                        o.put("min", mn);
                        o.put("max", mx);
                        o.put("avg", sum / ok);
                        o.put("jitter", ok > 1 ? jit / (ok - 1) : 0);
                    }
                } catch (Throwable t) {
                    try {
                        o.put("error", "Tidak bisa terhubung");
                    } catch (Throwable ignored) {
                    }
                }
                cb.done(o.toString());
            }
        }).start();
    }

    // ------------------------------------------------------------ aksi

    private static boolean start(Context c, Intent i) {
        try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    static boolean openPanel(Context c, String kind) {
        Intent i;
        if ("internet".equals(kind)) {
            i = new Intent(Build.VERSION.SDK_INT >= 29 ? "android.settings.panel.action.INTERNET_CONNECTIVITY" : Settings.ACTION_WIFI_SETTINGS);
        } else if ("wifi".equals(kind)) {
            i = new Intent(Settings.ACTION_WIFI_SETTINGS);
        } else if ("data".equals(kind)) {
            i = new Intent(Settings.ACTION_NETWORK_OPERATOR_SETTINGS);
        } else if ("bt".equals(kind)) {
            i = new Intent(Settings.ACTION_BLUETOOTH_SETTINGS);
        } else if ("airplane".equals(kind)) {
            i = new Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS);
        } else if ("location".equals(kind)) {
            i = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
        } else if ("dnd".equals(kind)) {
            i = new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS);
        } else if ("battery".equals(kind)) {
            i = new Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS);
        } else if ("display".equals(kind)) {
            i = new Intent(Settings.ACTION_DISPLAY_SETTINGS);
        } else if ("sound".equals(kind)) {
            i = new Intent(Settings.ACTION_SOUND_SETTINGS);
        } else if ("nfc".equals(kind)) {
            i = new Intent(Build.VERSION.SDK_INT >= 29 ? Settings.ACTION_NFC_SETTINGS : Settings.ACTION_WIRELESS_SETTINGS);
        } else if ("hotspot".equals(kind)) {
            i = new Intent("android.settings.TETHER_SETTINGS");
        } else if ("vpn".equals(kind)) {
            i = new Intent(Settings.ACTION_VPN_SETTINGS);
        } else if ("usage".equals(kind)) {
            i = new Intent("android.settings.DATA_USAGE_SETTINGS");
        } else if ("storage".equals(kind)) {
            i = new Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS);
        } else if ("writesettings".equals(kind)) {
            i = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + c.getPackageName()));
        } else {
            i = new Intent(Settings.ACTION_SETTINGS);
        }
        if (start(c, i)) return true;
        return start(c, new Intent(Settings.ACTION_SETTINGS));
    }

    static boolean launchPkg(Context c, String pkg) {
        try {
            Intent in = c.getPackageManager().getLaunchIntentForPackage(pkg);
            return in != null && start(c, in);
        } catch (Throwable t) {
            return false;
        }
    }

    /** Menjalankan aksi kontrol. Mengembalikan "ok", "needwrite", atau pesan singkat. */
    static String act(Context c, String a, String v) {
        try {
            if (a == null) return "aksi kosong";
            AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
            if (a.startsWith("volume:")) {
                String k = a.substring(7);
                int st = "music".equals(k) ? AudioManager.STREAM_MUSIC : "ring".equals(k) ? AudioManager.STREAM_RING
                        : "alarm".equals(k) ? AudioManager.STREAM_ALARM : "notif".equals(k) ? AudioManager.STREAM_NOTIFICATION
                        : "voice".equals(k) ? AudioManager.STREAM_VOICE_CALL : AudioManager.STREAM_SYSTEM;
                int val = Math.max(0, Math.min(Integer.parseInt(v), am.getStreamMaxVolume(st)));
                try {
                    am.setStreamVolume(st, val, 0);
                } catch (SecurityException se) {
                    return "Butuh izin Jangan Ganggu untuk mengubah suara ini.";
                }
                return "ok";
            }
            if ("brightness".equals(a)) {
                if (!Settings.System.canWrite(c)) return "needwrite";
                int val = Math.max(1, Math.min(255, Integer.parseInt(v)));
                Settings.System.putInt(c.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
                Settings.System.putInt(c.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, val);
                return "ok";
            }
            if ("autobright".equals(a)) {
                if (!Settings.System.canWrite(c)) return "needwrite";
                Settings.System.putInt(c.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS_MODE,
                        "1".equals(v) ? Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC : Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
                return "ok";
            }
            if ("rotate".equals(a)) {
                if (!Settings.System.canWrite(c)) return "needwrite";
                Settings.System.putInt(c.getContentResolver(), Settings.System.ACCELEROMETER_ROTATION, "1".equals(v) ? 1 : 0);
                return "ok";
            }
            if ("timeout".equals(a)) {
                if (!Settings.System.canWrite(c)) return "needwrite";
                Settings.System.putInt(c.getContentResolver(), Settings.System.SCREEN_OFF_TIMEOUT, Integer.parseInt(v));
                return "ok";
            }
            if ("ringer".equals(a)) {
                try {
                    am.setRingerMode(Integer.parseInt(v));
                } catch (SecurityException se) {
                    return "Mode senyap butuh izin Jangan Ganggu.";
                }
                return "ok";
            }
            if ("torch".equals(a)) return torch(c, v);
            if (a.startsWith("panel:")) {
                openPanel(c, a.substring(6));
                return "ok";
            }
            if (a.startsWith("app:")) return launchPkg(c, a.substring(4)) ? "ok" : "Aplikasi tidak bisa dibuka.";
        } catch (Throwable t) {
            return "Gagal: " + t.getClass().getSimpleName();
        }
        return "aksi tidak dikenal";
    }

    private static String torch(Context c, String v) {
        try {
            final CameraManager cm = (CameraManager) c.getSystemService(Context.CAMERA_SERVICE);
            String id = null;
            String[] ids = cm.getCameraIdList();
            for (int i = 0; i < ids.length; i++) {
                CameraCharacteristics cc = cm.getCameraCharacteristics(ids[i]);
                Boolean fl = cc.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                Integer facing = cc.get(CameraCharacteristics.LENS_FACING);
                if (fl != null && fl && facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) {
                    id = ids[i];
                    break;
                }
            }
            if (id == null) return "Perangkat tidak punya senter.";
            if (!torchReg) {
                torchReg = true;
                cm.registerTorchCallback(new CameraManager.TorchCallback() {
                    @Override
                    public void onTorchModeChanged(String cameraId, boolean enabled) {
                        torchOn = enabled;
                    }
                }, new Handler(Looper.getMainLooper()));
            }
            boolean want = (v == null || v.length() == 0) ? !(torchOn != null && torchOn) : "1".equals(v);
            cm.setTorchMode(id, want);
            torchOn = want;
            return "ok";
        } catch (SecurityException se) {
            return "Izinkan Kamera untuk Alfred AI di Pengaturan agar senter bisa menyala.";
        } catch (Throwable t) {
            return "Senter gagal: " + t.getClass().getSimpleName();
        }
    }

    // ------------------------------------------------------------ ikon aplikasi (disimpan sebagai berkas)

    static String iconUrl(Context c, String pkg, Drawable d, long stamp) {
        try {
            File dir = new File(c.getFilesDir(), "icons");
            if (!dir.exists()) dir.mkdirs();
            File f = new File(dir, pkg + ".png");
            if (!f.exists() || f.lastModified() < stamp) {
                int sz = 96;
                Bitmap b = Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888);
                Canvas cv = new Canvas(b);
                d.setBounds(0, 0, sz, sz);
                d.draw(cv);
                FileOutputStream fo = new FileOutputStream(f);
                b.compress(Bitmap.CompressFormat.PNG, 90, fo);
                fo.close();
            }
            return "file://" + f.getAbsolutePath() + "?v=" + f.lastModified();
        } catch (Throwable t) {
            return "";
        }
    }
}
