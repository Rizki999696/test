package com.alfredai.app;

import android.animation.Animator;
import android.app.ActivityOptions;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.IntentFilter;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.net.Uri;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.text.InputType;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.os.BatteryManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * Bulatan galaxy hitam yang melayang di atas aplikasi lain.
 *
 * - Ketuk bulatan: buka / tutup panel AI kecil.
 * - Tekan dan tahan bulatan: berubah menjadi kaca pembesar (kaca tembus pandang).
 *   Geser kaca ke atas tulisan lalu lepas: tulisan dibaca dan AI membalas di panel.
 *   Teks dibaca lewat Layanan Aksesibilitas; bila aplikasi (mis. game) tidak punya teks,
 *   dipakai OCR di perangkat (tanpa API key).
 * - Menggeser bulatan biasa hanya memindahkannya (tidak membaca tulisan).
 * - Panel bisa digeser dari mana saja kecuali area chat.
 * - Ukuran panel tetap saat layar diputar; bentuknya ikut miring (lebar dan tinggi ditukar).
 */
public class OverlayService extends Service {

    static final String CH = "alfred_overlay";
    static final int NID = 7001;
    static final String ACTION_STOP = "com.alfredai.app.OVERLAY_STOP";

    /** Skala ukuran panel terhadap ukuran dasar (lihat computePanelSize). Ubah angka ini untuk memperbesar/mengecilkan. */
    static final float PANEL_SCALE = 1.4f;

    /** Daftar aplikasi yang dicari: nama tampil, paket (pisah koma), awalan paket, kata kunci nama (= persis, ~ mengandung). */
    private static final String DESKTOP_UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

    /** nama, paket, awalan paket, kata kunci nama, alamat web (dibuka di dalam bulatan), "1" = tampilan desktop. */
    private static final String[][] APPDEF = {
            {"YouTube", "com.google.android.youtube", "", "=youtube", "https://m.youtube.com/", ""},
            {"TikTok", "com.zhiliaoapp.musically,com.ss.android.ugc.trill", "", "=tiktok", "https://www.tiktok.com/", ""},
            {"WhatsApp", "com.whatsapp", "", "=whatsapp", "https://web.whatsapp.com/", "1"},
            {"Instagram", "com.instagram.android", "", "=instagram", "https://www.instagram.com/", ""},
            {"TikTok Lite", "com.zhiliaoapp.musically.go,com.ss.android.ugc.aweme.lite", "", "=tiktok lite", "https://www.tiktok.com/", ""},
            {"Telegram", "org.telegram.messenger,org.telegram.messenger.web,org.telegram.plus", "", "=telegram", "https://web.telegram.org/a/", ""},
            {"Chrome", "com.android.chrome", "", "=chrome", "https://www.google.com/", ""},
            {"WhatsApp Business", "com.whatsapp.w4b", "", "~whatsapp business", "https://web.whatsapp.com/", "1"},
            {"ZArchiver", "ru.zdevs.zarchiver,ru.zdevs.zarchiver.pro", "", "~zarchiver", "", ""},
            {"Manajer MT", "", "bin.mt.plus", "~mt manager,manajer mt", "", ""},
            {"Pengaturan", "settings", "", "", "", ""},
            {"Mobile Legends", "", "com.mobile.legends", "~mobile legends", "", ""},
            {"Free Fire", "com.dts.freefireth,com.dts.freefiremax", "", "~free fire", "", ""},
            {"Magic Chess: Go Go", "", "com.mobiin", "~magic chess", "", ""},
            {"Spotify", "com.spotify.music", "", "=spotify", "https://open.spotify.com/", "1"}
    };

    private WindowManager wm;
    private SharedPreferences prefs;
    private final Handler ui = new Handler(Looper.getMainLooper());

    // ---- bulatan / kaca pembesar ----
    private BubbleView bubble;
    private WindowManager.LayoutParams bubbleLp;
    private int box;
    private int glass;
    private float bubFx = 1f;
    private float bubFy = 0.33f;
    private boolean lensMode = false;
    private boolean hintShown = false;
    private final Runnable lensExit = new Runnable() {
        @Override
        public void run() {
            exitLens();
        }
    };

    // ---- panel ----
    private PanelView panel;
    private LinearLayout col;
    private WebView web;
    private LinearLayout browserBox;
    private WebView bweb;
    private EditText urlEdit;
    private boolean browserShown = false;
    private int toolbarH;
    private boolean desktopMode = false;
    private String lastUrl = "";
    private int loadToken = 0;
    private View customView;
    private WebChromeClient.CustomViewCallback customCb;
    private boolean kbShifted = false;
    private int kbSavedY = 0;
    private boolean typing = false;
    private WindowManager.LayoutParams panelLp;
    private int panelW;
    private int panelH;
    private boolean panelPosSet = false;
    private boolean panelShown = false;
    private boolean webReady = false;
    private final ArrayList<String> pendingJs = new ArrayList<String>();
    private int barH;

    // ---- zona geser (dilaporkan oleh halaman) ----
    private volatile float[][] zones = new float[0][];
    private volatile char[] zoneModes = new char[0];
    private volatile boolean jsNoDrag = false;

    private int screenW;
    private int screenH;

    private float dragRawX;
    private float dragRawY;
    private int dragStartX;
    private int dragStartY;

    private static OverlayService current;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences("alfred", MODE_PRIVATE);
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (current != null && current != this) {
            current.removeAllViews();
        }
        current = this;
        startFg();
        if (!Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }
        readScreen();
        createBubble();
        ui.post(new Runnable() {
            @Override
            public void run() {
                try {
                    ensurePanel();
                } catch (Throwable ignored) {
                }
            }
        });
        refreshAppsAsync();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            prefs.edit().putBoolean("overlay_on", false).apply();
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }
        return START_STICKY;
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        float pfx = -1f;
        float pfy = -1f;
        if (panelLp != null && panelPosSet) {
            pfx = panelLp.x / (float) Math.max(1, screenW - panelW);
            pfy = panelLp.y / (float) Math.max(1, screenH - panelH);
        }
        readScreen();
        if (bubble != null && bubbleLp != null) {
            applyBubblePosition();
            try {
                wm.updateViewLayout(bubble, bubbleLp);
            } catch (Exception ignored) {
            }
        }
        if (panelLp != null) {
            computePanelSize();
            panelLp.width = panelW;
            panelLp.height = panelH;
            if (pfx >= 0) {
                panelLp.x = (int) (pfx * Math.max(0, screenW - panelW));
                panelLp.y = (int) (pfy * Math.max(0, screenH - panelH));
            }
            clampPanel();
            if (panelShown) {
                try {
                    wm.updateViewLayout(panel, panelLp);
                } catch (Exception ignored) {
                }
            }
        }
    }

    @Override
    public void onDestroy() {
        removeAllViews();
        if (current == this) current = null;
        super.onDestroy();
    }

    private void removeAllViews() {
        ui.removeCallbacks(lensExit);
        removePanelNow();
        if (bubble != null) {
            try {
                wm.removeView(bubble);
            } catch (Exception ignored) {
            }
            bubble = null;
        }
        if (bweb != null) {
            try {
                bweb.destroy();
            } catch (Exception ignored) {
            }
            bweb = null;
        }
        if (bweb != null) {
            try {
                bweb.destroy();
            } catch (Exception ignored) {
            }
            bweb = null;
        }
        if (web != null) {
            try {
                web.destroy();
            } catch (Exception ignored) {
            }
            web = null;
        }
        panel = null;
    }

    // ------------------------------------------------------------------ util

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private float dpf(float v) {
        return v * getResources().getDisplayMetrics().density;
    }

    private int type() {
        return Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
    }

    private void readScreen() {
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        screenW = dm.widthPixels;
        screenH = dm.heightPixels;
    }

    private int statusBarH() {
        int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : dp(24);
    }

    private int navBarH() {
        int id = getResources().getIdentifier("navigation_bar_height", "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : dp(24);
    }

    private static String quote(String s) {
        return JSONObject.quote(s).replace("\u2028", "\\u2028").replace("\u2029", "\\u2029");
    }

    private void toast(String msg) {
        try {
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        } catch (Exception ignored) {
        }
    }

    // ------------------------------------------------------- foreground notif

    private void startFg() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26 && nm != null) {
            NotificationChannel ch = new NotificationChannel(CH, "Bulatan Alfred", NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            nm.createNotificationChannel(ch);
        }
        Intent open = new Intent(this, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(
                this, 1, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, OverlayService.class);
        stop.setAction(ACTION_STOP);
        PendingIntent ps = PendingIntent.getService(
                this, 2, stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            b = new Notification.Builder(this, CH);
        } else {
            b = new Notification.Builder(this);
            b.setPriority(Notification.PRIORITY_MIN);
        }
        b.setSmallIcon(R.drawable.stat_galaxy)
                .setContentTitle("Alfred AI aktif")
                .setContentText("Bulatan galaxy sedang aktif")
                .setContentIntent(pi)
                .setOngoing(true);
        b.addAction(new Notification.Action.Builder(
                Icon.createWithResource(this, R.drawable.stat_galaxy), "Matikan", ps).build());
        startForeground(NID, b.build());
    }

    // ------------------------------------------------------ bulatan & kaca

    /**
     * Bulatan galaxy hitam dengan tepi beranimasi. Wajah bergantian: logo galaxy terang berputar,
     * jam (jam:menit + detik), tanggal, dan baterai. Saat lensa aktif menjadi kaca pembesar tembus pandang.
     */
    private class BubbleView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint logoP = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Bitmap logo;
        private final RectF rect = new RectF();
        private boolean lens = false;
        private SweepGradient sweep;
        private RadialGradient glow;
        private final long t0 = SystemClock.uptimeMillis();
        private long timeKey = -1;
        private String hm = "";
        private String ss = "";
        private String dayStr = "";
        private String monStr = "";
        private long batKey = -1;
        private int batPct = -1;
        private boolean batChg = false;
        private long rippleT0 = -1;
        private int rippleColor = 0xFFFFFFFF;
        private final String[] MON = {"JAN", "FEB", "MAR", "APR", "MEI", "JUN", "JUL", "AGU", "SEP", "OKT", "NOV", "DES"};
        private final Runnable tick = new Runnable() {
            @Override
            public void run() {
                if (!lens) {
                    invalidate();
                    postDelayed(this, 40);
                }
            }
        };

        BubbleView(Context c) {
            super(c);
            logo = BitmapFactory.decodeResource(getResources(), R.drawable.stat_galaxy);
            logoP.setColorFilter(new PorterDuffColorFilter(0xFFFFFFFF, PorterDuff.Mode.SRC_IN));
            logoP.setFilterBitmap(true);
            tp.setColor(Color.WHITE);
            tp.setTextAlign(Paint.Align.CENTER);
            tp.setTypeface(Typeface.DEFAULT_BOLD);
        }

        void ripple(int color) {
            rippleColor = color;
            rippleT0 = SystemClock.uptimeMillis();
        }

        void setLens(boolean l) {
            lens = l;
            removeCallbacks(tick);
            if (!l) post(tick);
            invalidate();
        }

        @Override
        protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            removeCallbacks(tick);
            post(tick);
        }

        @Override
        protected void onDetachedFromWindow() {
            removeCallbacks(tick);
            super.onDetachedFromWindow();
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            super.onSizeChanged(w, h, ow, oh);
            float cx = w / 2f;
            float cy = h / 2f;
            float r = glass / 2f;
            sweep = new SweepGradient(cx, cy, new int[]{0x00FFFFFF, 0x00FFFFFF, 0xFFFFFFFF, 0x00FFFFFF}, new float[]{0f, 0.5f, 0.92f, 1f});
            glow = new RadialGradient(cx, cy, r, new int[]{0x66FFFFFF, 0x22FFFFFF, 0x00FFFFFF}, new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP);
        }

        private void updateTime() {
            long key = System.currentTimeMillis() / 1000L;
            if (key == timeKey) return;
            timeKey = key;
            Calendar c = Calendar.getInstance();
            int h = c.get(Calendar.HOUR_OF_DAY);
            int m = c.get(Calendar.MINUTE);
            int sec = c.get(Calendar.SECOND);
            hm = (h < 10 ? "0" : "") + h + ":" + (m < 10 ? "0" : "") + m;
            ss = (sec < 10 ? "0" : "") + sec;
            dayStr = String.valueOf(c.get(Calendar.DAY_OF_MONTH));
            monStr = MON[c.get(Calendar.MONTH)];
        }

        private void updateBattery() {
            long k = System.currentTimeMillis() / 5000L;
            if (k == batKey) return;
            batKey = k;
            try {
                Intent b = OverlayService.this.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
                if (b != null) {
                    int level = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                    int scale = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
                    batPct = scale > 0 ? level * 100 / scale : -1;
                    int st = b.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
                    batChg = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL;
                }
            } catch (Throwable ignored) {
            }
        }

        private float win(long t, long a, long b) {
            if (t < a || t > b) return 0f;
            long f = 400;
            if (t < a + f) return (t - a) / (float) f;
            if (t > b - f) return (b - t) / (float) f;
            return 1f;
        }

        private void face(Canvas c, float cx, float cy, String l1, String l2, float alpha, float s1, float s2) {
            if (alpha <= 0f) return;
            int al = (int) (255 * alpha);
            tp.setAlpha(al);
            tp.setTextSize(glass * s1);
            float y1 = cy - glass * 0.04f;
            c.drawText(l1, cx, y1, tp);
            tp.setTextSize(glass * s2);
            tp.setAlpha(al);
            c.drawText(l2, cx, y1 + glass * 0.27f, tp);
        }

        @Override
        protected void onDraw(Canvas c) {
            float cx = getWidth() / 2f;
            float cy = getHeight() / 2f;
            float r = glass / 2f;
            if (lens) {
                p.setShader(null);
                p.setStyle(Paint.Style.FILL);
                p.setColor(0x12FFFFFF);
                c.drawCircle(cx, cy, r, p);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeCap(Paint.Cap.ROUND);
                p.setStrokeWidth(dpf(5));
                p.setColor(0x99000000);
                c.drawCircle(cx, cy, r - dpf(2.5f), p);
                p.setStrokeWidth(dpf(2.5f));
                p.setColor(0xFFFFFFFF);
                c.drawCircle(cx, cy, r - dpf(2.5f), p);
                float a = r * 0.7071f;
                float sx = cx + a;
                float sy = cy + a;
                p.setStrokeWidth(dpf(7));
                p.setColor(0x99000000);
                c.drawLine(sx, sy, sx + dpf(12), sy + dpf(12), p);
                p.setStrokeWidth(dpf(4));
                p.setColor(0xFFFFFFFF);
                c.drawLine(sx, sy, sx + dpf(12), sy + dpf(12), p);
                return;
            }

            long now = SystemClock.uptimeMillis();
            long t = (now - t0) % 21000L;
            float aClock = win(t, 5000, 8500);
            float aDate = win(t, 11500, 14000);
            float aBat = win(t, 17000, 19500);
            float ca = Math.max(aClock, Math.max(aDate, aBat));

            p.setShader(null);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF000000);
            c.drawCircle(cx, cy, r, p);
            if (glow != null) {
                p.setShader(glow);
                c.drawCircle(cx, cy, r, p);
                p.setShader(null);
            }
            float pulse = 0.5f + 0.5f * (float) Math.sin((now % 2400L) / 2400f * 2f * Math.PI);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dpf(1.2f));
            p.setColor(((int) (0x55 + 0x55 * pulse) << 24) | 0x00FFFFFF);
            c.drawCircle(cx, cy, r - dpf(0.6f), p);
            if (sweep != null) {
                c.save();
                c.rotate((now % 2600L) / 2600f * 360f, cx, cy);
                p.setShader(sweep);
                p.setStrokeCap(Paint.Cap.ROUND);
                p.setStrokeWidth(dpf(2.6f));
                c.drawCircle(cx, cy, r - dpf(1.6f), p);
                p.setShader(null);
                c.restore();
            }
            if (ca < 1f && logo != null) {
                float spin = (now % 14000L) / 14000f * 360f;
                float sz = r * 1.6f * (1f - 0.4f * ca);
                c.save();
                c.rotate(spin + ca * 140f, cx, cy);
                logoP.setAlpha((int) (140 * (1f - ca)));
                rect.set(cx - sz / 2f - dpf(2f), cy - sz / 2f - dpf(2f), cx + sz / 2f + dpf(2f), cy + sz / 2f + dpf(2f));
                c.drawBitmap(logo, null, rect, logoP);
                logoP.setAlpha((int) (255 * (1f - ca)));
                rect.set(cx - sz / 2f, cy - sz / 2f, cx + sz / 2f, cy + sz / 2f);
                c.drawBitmap(logo, null, rect, logoP);
                c.drawBitmap(logo, null, rect, logoP);
                c.restore();
            }
            if (ca > 0f) {
                updateTime();
                face(c, cx, cy, hm, ss, aClock, 0.27f, 0.24f);
                face(c, cx, cy, dayStr, monStr, aDate, 0.36f, 0.22f);
                if (aBat > 0f) {
                    updateBattery();
                    face(c, cx, cy, batPct < 0 ? "--" : batPct + "%", batChg ? "ISI" : "BAT", aBat, 0.30f, 0.22f);
                }
            }
            if (rippleT0 > 0) {
                float k = (now - rippleT0) / 550f;
                if (k < 1f) {
                    float rr = r + (box / 2f - r - dpf(1.5f)) * k;
                    p.setStyle(Paint.Style.STROKE);
                    p.setShader(null);
                    p.setStrokeWidth(dpf(2f));
                    p.setColor((((int) (170 * (1f - k))) << 24) | (rippleColor & 0x00FFFFFF));
                    c.drawCircle(cx, cy, rr, p);
                } else {
                    rippleT0 = -1;
                }
            }
        }
    }

    private void createBubble() {
        glass = dp(56);
        box = dp(72);
        bubFx = prefs.getFloat("ov_fx", 1f);
        bubFy = prefs.getFloat("ov_fy", 0.33f);

        BubbleView v = new BubbleView(this);
        bubbleLp = new WindowManager.LayoutParams(
                box, box, type(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        bubbleLp.gravity = Gravity.TOP | Gravity.START;
        applyBubblePosition();
        v.setOnTouchListener(new BubbleTouch());
        try {
            wm.addView(v, bubbleLp);
            bubble = v;
        } catch (Exception e) {
            stopSelf();
        }
    }

    private int inset() {
        return (box - glass) / 2;
    }

    /** Posisi bulatan dihitung dari pecahan layar supaya tetap pas saat layar diputar. */
    private void applyBubblePosition() {
        int rx = screenW - box + 2 * inset();
        int ry = screenH - box;
        bubbleLp.x = (int) (bubFx * rx) - inset();
        bubbleLp.y = (int) (bubFy * Math.max(0, ry));
        clampBubble();
    }

    private void storeBubbleFractions() {
        int rx = Math.max(1, screenW - box + 2 * inset());
        int ry = Math.max(1, screenH - box);
        bubFx = Math.max(0f, Math.min(1f, (bubbleLp.x + inset()) / (float) rx));
        bubFy = Math.max(0f, Math.min(1f, bubbleLp.y / (float) ry));
        prefs.edit().putFloat("ov_fx", bubFx).putFloat("ov_fy", bubFy).apply();
    }

    private void clampBubble() {
        if (bubbleLp == null) return;
        int minX = -inset();
        int maxX = screenW - box + inset();
        if (bubbleLp.x < minX) bubbleLp.x = minX;
        if (bubbleLp.x > maxX) bubbleLp.x = maxX;
        if (bubbleLp.y < 0) bubbleLp.y = 0;
        if (bubbleLp.y > screenH - box) bubbleLp.y = screenH - box;
    }

    private void snapToEdge() {
        if (bubble == null || bubbleLp == null) return;
        final int from = bubbleLp.x;
        final int to = (bubbleLp.x + box / 2 < screenW / 2) ? -inset() : screenW - box + inset();
        ValueAnimator a = ValueAnimator.ofInt(from, to);
        a.setDuration(160);
        a.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator va) {
                if (bubble == null) return;
                bubbleLp.x = (Integer) va.getAnimatedValue();
                try {
                    wm.updateViewLayout(bubble, bubbleLp);
                } catch (Exception ignored) {
                }
            }
        });
        a.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                storeBubbleFractions();
            }
        });
        a.start();
    }

    private void enterLens() {
        lensMode = true;
        if (bubble != null) {
            bubble.setLens(true);
            bubble.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
        }
        if (!hintShown) {
            hintShown = true;
            toast("Kaca pembesar aktif. Geser ke tulisan lalu lepas.");
        }
        scheduleLensExit();
    }

    private void exitLens() {
        ui.removeCallbacks(lensExit);
        lensMode = false;
        if (bubble != null) {
            bubble.setAlpha(1f);
            bubble.setLens(false);
        }
        if (panel != null) panel.setAlpha(1f);
    }

    private void scheduleLensExit() {
        ui.removeCallbacks(lensExit);
        ui.postDelayed(lensExit, 12000);
    }

    private class BubbleTouch implements View.OnTouchListener {
        private int startX;
        private int startY;
        private float downX;
        private float downY;
        private float lastX;
        private float lastY;
        private boolean moved;
        private boolean longFired;
        private final Runnable longRun = new Runnable() {
            @Override
            public void run() {
                if (!moved) {
                    longFired = true;
                    startX = bubbleLp.x;
                    startY = bubbleLp.y;
                    downX = lastX;
                    downY = lastY;
                    enterLens();
                }
            }
        };

        @Override
        public boolean onTouch(View v, MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    startX = bubbleLp.x;
                    startY = bubbleLp.y;
                    downX = e.getRawX();
                    downY = e.getRawY();
                    lastX = downX;
                    lastY = downY;
                    moved = false;
                    longFired = false;
                    ui.removeCallbacks(lensExit);
                    v.setScaleX(0.93f);
                    v.setScaleY(0.93f);
                    if (!lensMode) ui.postDelayed(longRun, 350);
                    return true;
                case MotionEvent.ACTION_MOVE: {
                    lastX = e.getRawX();
                    lastY = e.getRawY();
                    float dx = lastX - downX;
                    float dy = lastY - downY;
                    if (!moved && Math.sqrt(dx * dx + dy * dy) > dp(8)) {
                        moved = true;
                        ui.removeCallbacks(longRun);
                    }
                    if (moved) {
                        bubbleLp.x = (int) (startX + dx);
                        bubbleLp.y = (int) (startY + dy);
                        clampBubble();
                        try {
                            wm.updateViewLayout(bubble, bubbleLp);
                        } catch (Exception ignored) {
                        }
                    }
                    return true;
                }
                case MotionEvent.ACTION_UP:
                    ui.removeCallbacks(longRun);
                    v.setScaleX(1f);
                    v.setScaleY(1f);
                    if (lensMode) {
                        if (moved) {
                            captureAtLens();
                        } else if (longFired) {
                            scheduleLensExit();
                        } else {
                            exitLens();
                        }
                    } else if (!moved) {
                        v.performClick();
                        togglePanel();
                    } else {
                        snapToEdge();
                    }
                    return true;
                case MotionEvent.ACTION_CANCEL:
                    ui.removeCallbacks(longRun);
                    v.setScaleX(1f);
                    v.setScaleY(1f);
                    if (lensMode) scheduleLensExit();
                    return true;
                default:
                    return false;
            }
        }
    }

    // ------------------------------------------------- membaca tulisan

    private void captureAtLens() {
        final int cx = bubbleLp.x + box / 2;
        final int cy = bubbleLp.y + box / 2;
        if (!AlfredAccessService.isRunning()) {
            exitLens();
            showPanel();
            runJs("window.alfredNeedAccess && window.alfredNeedAccess()");
            return;
        }
        String t = AlfredAccessService.textAtTree(cx, cy);
        if (t != null && t.trim().length() > 0) {
            deliver(t);
            return;
        }
        if (Build.VERSION.SDK_INT < 30) {
            toast("Tidak ada teks yang bisa dibaca di titik ini.");
            scheduleLensExit();
            return;
        }
        // tidak ada teks di pohon aksesibilitas (mis. game): baca dari tangkapan layar (OCR di perangkat)
        if (bubble != null) bubble.setAlpha(0f);
        if (panelShown && panel != null) panel.setAlpha(0f);
        final Runnable restore = new Runnable() {
            @Override
            public void run() {
                if (bubble != null) bubble.setAlpha(1f);
                if (panel != null) panel.setAlpha(1f);
            }
        };
        ui.postDelayed(restore, 4000);
        ui.postDelayed(new Runnable() {
            @Override
            public void run() {
                AlfredAccessService.ocrAt(cx, cy, new AlfredAccessService.OcrCallback() {
                    @Override
                    public void onResult(String text, String err) {
                        ui.removeCallbacks(restore);
                        restore.run();
                        if (text != null && text.trim().length() > 0) {
                            deliver(text);
                        } else {
                            toast(err != null ? err : "Tidak ada tulisan terbaca di titik ini.");
                            scheduleLensExit();
                        }
                    }
                });
            }
        }, 150);
    }

    private void deliver(String t) {
        exitLens();
        if (bubble != null) bubble.ripple(0xFF7CFFB2);
        showPanel();
        runJs("window.alfredCapture && window.alfredCapture(" + quote(t) + ")");
        snapToEdge();
    }

    // -------------------------------------------------------------- panel

    private class PanelView extends FrameLayout {
        private float dX;
        private float dY;
        private char zoneMode = 0;
        private boolean dragging = false;
        private boolean armed = false;
        private final Runnable armRun = new Runnable() {
            @Override
            public void run() {
                if (!jsNoDrag) {
                    armed = true;
                    performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                }
            }
        };

        PanelView(Context c) {
            super(c);
        }

        private boolean inUrlField(float x, float y) {
            if (!browserShown || urlEdit == null || panel == null) return false;
            int[] a = new int[2];
            int[] b = new int[2];
            urlEdit.getLocationInWindow(a);
            panel.getLocationInWindow(b);
            float rx = a[0] - b[0];
            float ry = a[1] - b[1];
            return x >= rx && x <= rx + urlEdit.getWidth() && y >= ry && y <= ry + urlEdit.getHeight();
        }

        private char zoneAt(float x, float y) {
            if (y < barH) return 0;
            if (browserShown) {
                if (inUrlField(x, y)) return 'i';
                return y < barH + toolbarH ? 'd' : 'l';
            }
            float d = getResources().getDisplayMetrics().density;
            float wx = x / d;
            float wy = (y - barH) / d;
            float[][] z = zones;
            char[] m = zoneModes;
            char found = 0;
            for (int i = 0; i < z.length && i < m.length; i++) {
                float[] r = z[i];
                if (wx >= r[0] && wx <= r[0] + r[2] && wy >= r[1] && wy <= r[1] + r[3]) {
                    if (m[i] == 'i') return 'i';
                    found = m[i];
                }
            }
            return found;
        }

        @Override
        public boolean onInterceptTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    dragging = false;
                    armed = false;
                    ui.removeCallbacks(armRun);
                    dX = e.getRawX();
                    dY = e.getRawY();
                    zoneMode = zoneAt(e.getX(), e.getY());
                    if (zoneMode == 'i') {
                        typing = true;
                        focusNow();
                        showImeBurst();
                    } else if (zoneMode == 'l') {
                        ui.postDelayed(armRun, 320);
                    }
                    return false;
                case MotionEvent.ACTION_MOVE: {
                    if (dragging) return true;
                    float dx = e.getRawX() - dX;
                    float dy = e.getRawY() - dY;
                    boolean far = Math.sqrt(dx * dx + dy * dy) > dp(8);
                    if (far && !jsNoDrag) {
                        if (zoneMode == 'd' || (zoneMode == 'l' && armed)) {
                            dragging = true;
                            ui.removeCallbacks(armRun);
                            dragStart(dX, dY);
                            return true;
                        }
                    }
                    if (far) ui.removeCallbacks(armRun);
                    return false;
                }
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    ui.removeCallbacks(armRun);
                    return false;
                default:
                    return false;
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_OUTSIDE:
                    // sentuhan keyboard juga dianggap "di luar"; jangan tutup keyboard saat mengetik
                    if (typing && isPanelFocusable() && e.getRawY() > screenH * 0.48f) return true;
                    typing = false;
                    blurNow();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (dragging) {
                        dragMove(e.getRawX(), e.getRawY());
                        return true;
                    }
                    return false;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (dragging) {
                        dragging = false;
                        dragEnd();
                        return true;
                    }
                    return false;
                default:
                    return dragging;
            }
        }

        @Override
        public boolean dispatchKeyEvent(KeyEvent e) {
            if (e.getKeyCode() == KeyEvent.KEYCODE_BACK) {
                if (e.getAction() == KeyEvent.ACTION_UP) {
                    if (customView != null) {
                        hideCustomView();
                    } else if (browserShown && bweb != null && bweb.canGoBack()) {
                        bweb.goBack();
                    } else if (browserShown) {
                        closeBrowser();
                    } else {
                        hidePanel();
                    }
                }
                return true;
            }
            return super.dispatchKeyEvent(e);
        }
    }

    private void hideCustomView() {
        if (customView != null && panel != null) {
            panel.removeView(customView);
            customView = null;
            if (customCb != null) customCb.onCustomViewHidden();
            customCb = null;
        }
    }

    private void dragStart(float rawX, float rawY) {
        if (panelLp == null) return;
        kbShifted = false;
        dragRawX = rawX;
        dragRawY = rawY;
        dragStartX = panelLp.x;
        dragStartY = panelLp.y;
    }

    private void dragMove(float rawX, float rawY) {
        if (panelLp == null || panel == null) return;
        panelLp.x = (int) (dragStartX + rawX - dragRawX);
        panelLp.y = (int) (dragStartY + rawY - dragRawY);
        clampPanel();
        try {
            wm.updateViewLayout(panel, panelLp);
        } catch (Exception ignored) {
        }
    }

    private void dragEnd() {
        if (panelLp == null) return;
        prefs.edit().putInt("pn_x", panelLp.x).putInt("pn_y", panelLp.y).apply();
    }

    private class BarTouch implements View.OnTouchListener {
        @Override
        public boolean onTouch(View v, MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    dragStart(e.getRawX(), e.getRawY());
                    return true;
                case MotionEvent.ACTION_MOVE:
                    dragMove(e.getRawX(), e.getRawY());
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    dragEnd();
                    return true;
                default:
                    return false;
            }
        }
    }

    private void ensurePanel() {
        if (panel != null) return;
        barH = dp(24);
        panel = new PanelView(this);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFF0B0B0B);
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), 0xFF2A2A2A);
        panel.setBackground(bg);
        panel.setClipToOutline(true);
        panel.setFocusableInTouchMode(true);

        col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);

        FrameLayout bar = new FrameLayout(this);
        bar.setBackgroundColor(0xFF050505);
        View pill = new View(this);
        GradientDrawable pg = new GradientDrawable();
        pg.setColor(0xFF5A5A5A);
        pg.setCornerRadius(dp(3));
        pill.setBackground(pg);
        bar.addView(pill, new FrameLayout.LayoutParams(dp(40), dp(4), Gravity.CENTER));
        bar.setOnTouchListener(new BarTouch());
        col.addView(bar, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, barH));

        web = new WebView(new ContextThemeWrapper(getApplicationContext(), R.style.Theme_Alfred));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.setBackgroundColor(0xFF0B0B0B);
        web.addJavascriptInterface(new PanelBridge(), "AlfredPanel");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                markReady();
            }
        });
        web.loadUrl("file:///android_asset/overlay.html");
        col.addView(web, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        panel.addView(col, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
    }

    private void markReady() {
        if (webReady) return;
        webReady = true;
        for (int i = 0; i < pendingJs.size(); i++) {
            if (web != null) web.evaluateJavascript(pendingJs.get(i), null);
        }
        pendingJs.clear();
    }

    private void runJs(final String code) {
        ui.post(new Runnable() {
            @Override
            public void run() {
                if (web == null) return;
                if (webReady) {
                    web.evaluateJavascript(code, null);
                } else {
                    pendingJs.add(code);
                }
            }
        });
    }

    private void togglePanel() {
        if (bubble != null) bubble.ripple(0xFFFFFFFF);
        if (panelShown) {
            hidePanel();
        } else {
            showPanel();
        }
    }

    /**
     * Ukuran dasar = setengah sisi pendek layar (min 230dp) x seperempat sisi panjang (min 270dp),
     * dikali PANEL_SCALE. Di layar miring lebar dan tinggi ditukar; ukuran tidak melebar mengikuti layar.
     */
    private void computePanelSize() {
        int sh = Math.min(screenW, screenH);
        int lg = Math.max(screenW, screenH);
        int usableLong = lg - statusBarH() - navBarH();
        int baseW = Math.max(sh / 2, dp(230));
        if (baseW > sh - dp(16)) baseW = sh - dp(16);
        int baseH = Math.max(usableLong / 4, dp(270));
        if (baseH > usableLong - dp(16)) baseH = usableLong - dp(16);
        int w = Math.max(Math.round(baseW * PANEL_SCALE), dp(150));
        int h = Math.max(Math.round(baseH * PANEL_SCALE), dp(180));
        boolean landscape = screenW > screenH;
        panelW = landscape ? h : w;
        panelH = landscape ? w : h;
        if (panelW > screenW - dp(8)) panelW = screenW - dp(8);
        if (panelH > screenH - dp(8)) panelH = screenH - dp(8);
    }

    private void clampPanel() {
        if (panelLp == null) return;
        int minY = Math.min(statusBarH(), Math.max(0, screenH - panelH));
        if (panelLp.x < 0) panelLp.x = 0;
        if (panelLp.x > screenW - panelW) panelLp.x = Math.max(0, screenW - panelW);
        if (panelLp.y < minY) panelLp.y = minY;
        if (panelLp.y > screenH - panelH) panelLp.y = Math.max(0, screenH - panelH);
    }

    private void showPanel() {
        ensurePanel();
        computePanelSize();
        if (panelLp == null) {
            panelLp = new WindowManager.LayoutParams(
                    panelW, panelH, type(),
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
                    PixelFormat.TRANSLUCENT);
            panelLp.gravity = Gravity.TOP | Gravity.START;
            panelLp.softInputMode = Build.VERSION.SDK_INT >= 30
                    ? WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING
                    : WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE;
        }
        panelLp.width = panelW;
        panelLp.height = panelH;
        panelLp.flags |= WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        kbShifted = false;

        if (!panelPosSet) {
            if (prefs.contains("pn_x") && prefs.contains("pn_y")) {
                panelLp.x = prefs.getInt("pn_x", 0);
                panelLp.y = prefs.getInt("pn_y", 0);
            } else {
                int bcx = bubbleLp.x + box / 2;
                int bcy = bubbleLp.y + box / 2;
                panelLp.x = bcx < screenW / 2 ? dp(8) : screenW - panelW - dp(8);
                panelLp.y = bcy < screenH / 2 ? bubbleLp.y + box + dp(4) : bubbleLp.y - panelH - dp(4);
            }
            panelPosSet = true;
        }
        clampPanel();

        boolean wasShown = panelShown;
        try {
            if (panelShown) {
                panel.animate().cancel();
                panel.setAlpha(1f);
                panel.setScaleX(1f);
                panel.setScaleY(1f);
                wm.updateViewLayout(panel, panelLp);
            } else {
                wm.addView(panel, panelLp);
                panelShown = true;
            }
        } catch (Exception e) {
            panelShown = false;
        }
        if (!wasShown && panelShown) animateIn();
    }

    private void animateIn() {
        if (panel == null || bubbleLp == null || panelLp == null) return;
        panel.animate().cancel();
        panel.setPivotX(Math.max(0, Math.min(panelW, bubbleLp.x + box / 2f - panelLp.x)));
        panel.setPivotY(Math.max(0, Math.min(panelH, bubbleLp.y + box / 2f - panelLp.y)));
        panel.setAlpha(0f);
        panel.setScaleX(0.78f);
        panel.setScaleY(0.78f);
        panel.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(260)
                .setInterpolator(new OvershootInterpolator(1.05f)).start();
    }

    private void hidePanel() {
        if (!(panelShown && panel != null)) return;
        typing = false;
        restoreKb();
        hideIme();
        if (panelLp != null) {
            panelLp.flags |= WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
            try {
                wm.updateViewLayout(panel, panelLp);
            } catch (Exception ignored) {
            }
        }
        panel.animate().cancel();
        panel.animate().alpha(0f).scaleX(0.88f).scaleY(0.88f).setDuration(140)
                .setInterpolator(new DecelerateInterpolator())
                .withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        removePanelNow();
                    }
                }).start();
    }

    private void removePanelNow() {
        if (panelShown && panel != null) {
            try {
                wm.removeView(panel);
            } catch (Exception ignored) {
            }
            panelShown = false;
            panel.setAlpha(1f);
            panel.setScaleX(1f);
            panel.setScaleY(1f);
        }
    }

    // ------------------------------------------------------------ keyboard

    private boolean isPanelFocusable() {
        return panelLp != null && (panelLp.flags & WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE) == 0;
    }

    /** Ambil fokus sekarang juga (sinkron), lalu angkat panel di atas keyboard bila perlu. */
    private void focusNow() {
        if (panelLp == null || !panelShown || panel == null) return;
        if (!isPanelFocusable()) {
            panelLp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
            try {
                wm.updateViewLayout(panel, panelLp);
            } catch (Exception ignored) {
            }
        }
        liftAboveKeyboard();
    }

    /** Lepaskan fokus supaya keyboard aplikasi lain bisa muncul. */
    private void blurNow() {
        restoreKb();
        if (panelLp == null || !panelShown || panel == null) return;
        if (isPanelFocusable()) {
            panelLp.flags |= WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
            try {
                wm.updateViewLayout(panel, panelLp);
            } catch (Exception ignored) {
            }
        }
        hideIme();
    }

    private void liftAboveKeyboard() {
        if (panelLp == null || kbShifted) return;
        int kbTop = (int) (screenH * (screenW > screenH ? 0.5f : 0.56f));
        if (panelLp.y + panelH > kbTop) {
            kbSavedY = panelLp.y;
            panelLp.y = Math.max(statusBarH(), kbTop - panelH);
            kbShifted = true;
            try {
                wm.updateViewLayout(panel, panelLp);
            } catch (Exception ignored) {
            }
        }
    }

    private void restoreKb() {
        if (!kbShifted || panelLp == null) return;
        kbShifted = false;
        panelLp.y = kbSavedY;
        if (panelShown && panel != null) {
            try {
                wm.updateViewLayout(panel, panelLp);
            } catch (Exception ignored) {
            }
        }
    }

    private void setPanelFocusable(final boolean f) {
        ui.post(new Runnable() {
            @Override
            public void run() {
                if (f) {
                    typing = true;
                    focusNow();
                    showImeBurst();
                } else {
                    typing = false;
                    blurNow();
                }
            }
        });
    }

    /** Minta keyboard beberapa kali berturut-turut supaya cepat dan tidak terlewat. */
    private void showImeBurst() {
        final View target = (browserShown && urlEdit != null && urlEdit.hasFocus()) ? (View) urlEdit : (View) (browserShown ? bweb : web);
        if (target == null) return;
        if (!(target instanceof EditText)) target.requestFocus();
        final InputMethodManager m = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (m == null) return;
        try {
            m.showSoftInput(target, 0);
        } catch (Exception ignored) {
        }
        ui.postDelayed(new Runnable() {
            @Override
            public void run() {
                try {
                    if (!typing) return;
                    m.restartInput(target);
                    m.showSoftInput(target, 0);
                } catch (Exception ignored) {
                }
            }
        }, 70);
        ui.postDelayed(new Runnable() {
            @Override
            public void run() {
                try {
                    if (typing) m.showSoftInput(target, 0);
                } catch (Exception ignored) {
                }
            }
        }, 220);
    }

    private void hideIme() {
        try {
            InputMethodManager m = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            if (m != null && web != null) m.hideSoftInputFromWindow(web.getWindowToken(), 0);
        } catch (Exception ignored) {
        }
    }

    // ----------------------------------------------------- daftar aplikasi

    private boolean defMatches(String[] d, String pkg, String label) {
        if (d[1].length() > 0) {
            String[] ps = d[1].split(",");
            for (int i = 0; i < ps.length; i++) {
                if (ps[i].equals(pkg)) return true;
            }
        }
        if (d[2].length() > 0 && pkg.startsWith(d[2])) return true;
        if (d[3].length() > 0) {
            boolean exact = d[3].charAt(0) == '=';
            String[] ks = d[3].substring(1).split(",");
            for (int i = 0; i < ks.length; i++) {
                if (exact ? label.equals(ks[i]) : label.contains(ks[i])) return true;
            }
        }
        return false;
    }

    private String scanApps() {
        JSONArray out = new JSONArray();
        try {
            PackageManager pm = getPackageManager();
            Intent main = new Intent(Intent.ACTION_MAIN);
            main.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> list = pm.queryIntentActivities(main, 0);
            java.util.HashSet<String> used = new java.util.HashSet<String>();
            used.add(getPackageName());

            for (int k = 0; k < APPDEF.length; k++) {
                String[] d = APPDEF[k];
                JSONObject o = new JSONObject();
                if ("settings".equals(d[1])) {
                    ResolveInfo r = pm.resolveActivity(new Intent(Settings.ACTION_SETTINGS), 0);
                    String name = d[0];
                    String icon = "";
                    if (r != null) {
                        CharSequence l = r.loadLabel(pm);
                        if (l != null && l.length() > 0) name = l.toString();
                        icon = SysTools.iconUrl(this, "settings", r.loadIcon(pm), 0L);
                        used.add(r.activityInfo.packageName);
                    }
                    o.put("p", "settings");
                    o.put("n", name);
                    o.put("i", icon);
                    o.put("w", "");
                    o.put("pr", k);
                    out.put(o);
                    continue;
                }
                ResolveInfo found = null;
                String foundLabel = null;
                for (int i = 0; i < list.size() && found == null; i++) {
                    ResolveInfo ri = list.get(i);
                    String pkg = ri.activityInfo.packageName;
                    if (used.contains(pkg)) continue;
                    CharSequence cs = ri.loadLabel(pm);
                    String label = cs == null ? "" : cs.toString().toLowerCase().trim();
                    if (defMatches(d, pkg, label)) {
                        found = ri;
                        foundLabel = cs == null ? d[0] : cs.toString();
                    }
                }
                if (found != null) {
                    String pkg = found.activityInfo.packageName;
                    used.add(pkg);
                    long stamp = 0L;
                    try {
                        stamp = pm.getPackageInfo(pkg, 0).lastUpdateTime;
                    } catch (Throwable ignored) {
                    }
                    o.put("p", pkg);
                    o.put("n", foundLabel == null || foundLabel.length() == 0 ? d[0] : foundLabel);
                    o.put("i", SysTools.iconUrl(this, pkg, found.loadIcon(pm), stamp));
                    o.put("w", d[4]);
                    o.put("dsk", "1".equals(d[5]));
                    o.put("pr", k);
                    out.put(o);
                }
            }

            ArrayList<ResolveInfo> rest = new ArrayList<ResolveInfo>();
            for (int i = 0; i < list.size(); i++) {
                ResolveInfo ri = list.get(i);
                if (!used.contains(ri.activityInfo.packageName)) rest.add(ri);
            }
            final PackageManager fpm = pm;
            java.util.Collections.sort(rest, new java.util.Comparator<ResolveInfo>() {
                @Override
                public int compare(ResolveInfo a, ResolveInfo b) {
                    String x = String.valueOf(a.loadLabel(fpm)).toLowerCase();
                    String y = String.valueOf(b.loadLabel(fpm)).toLowerCase();
                    return x.compareTo(y);
                }
            });
            for (int i = 0; i < rest.size(); i++) {
                ResolveInfo ri = rest.get(i);
                String pkg = ri.activityInfo.packageName;
                if (used.contains(pkg)) continue;
                used.add(pkg);
                long stamp = 0L;
                try {
                    stamp = pm.getPackageInfo(pkg, 0).lastUpdateTime;
                } catch (Throwable ignored) {
                }
                JSONObject o = new JSONObject();
                CharSequence cs = ri.loadLabel(pm);
                o.put("p", pkg);
                o.put("n", cs == null ? pkg : cs.toString());
                o.put("i", SysTools.iconUrl(this, pkg, ri.loadIcon(pm), stamp));
                o.put("w", "");
                o.put("pr", -1);
                out.put(o);
            }
        } catch (Throwable ignored) {
        }
        return out.toString();
    }

    private void refreshAppsAsync() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                final String json = scanApps();
                prefs.edit().putString("apps_json", json).apply();
                runJs("window.alfredApps && window.alfredApps(" + quote(json) + ")");
            }
        }).start();
    }

    private void launchApp(String pkg) {
        try {
            String webUrl = "";
            boolean desktop = false;
            JSONArray arr = new JSONArray(prefs.getString("apps_json", "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                if (pkg.equals(o.optString("p"))) {
                    webUrl = o.optString("w", "");
                    desktop = o.optBoolean("dsk", false);
                }
            }
            if (webUrl.length() > 0) {
                openBrowser(webUrl, desktop);
                return;
            }
            // aplikasi asli tidak bisa ditanam di dalam bulatan; dibuka sebagai jendela mengambang jika HP mendukung
            Intent in;
            if ("settings".equals(pkg)) {
                in = new Intent(Settings.ACTION_SETTINGS);
            } else {
                in = getPackageManager().getLaunchIntentForPackage(pkg);
            }
            if (in == null) return;
            in.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ActivityOptions ao = ActivityOptions.makeBasic();
            if (panelLp != null) {
                ao.setLaunchBounds(new Rect(panelLp.x, panelLp.y, panelLp.x + panelW, panelLp.y + panelH));
            }
            hidePanel();
            startActivity(in, ao.toBundle());
            toast("Dibuka sebagai jendela mengambang jika HP mendukung (freeform).");
        } catch (Exception ignored) {
        }
    }

    // ----------------------------------------- browser mini di dalam bulatan

    private TextView toolBtn(String t, View.OnClickListener l) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextColor(0xFFFFFFFF);
        v.setTextSize(16f);
        v.setGravity(Gravity.CENTER);
        v.setOnClickListener(l);
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(34), LinearLayout.LayoutParams.MATCH_PARENT));
        return v;
    }

    private void buildBrowser() {
        toolbarH = dp(40);
        browserBox = new LinearLayout(this);
        browserBox.setOrientation(LinearLayout.VERTICAL);
        browserBox.setBackgroundColor(0xFF0B0B0B);

        LinearLayout tb = new LinearLayout(this);
        tb.setOrientation(LinearLayout.HORIZONTAL);
        tb.setGravity(Gravity.CENTER_VERTICAL);
        tb.setBackgroundColor(0xFF050505);
        tb.setPadding(dp(2), 0, dp(2), 0);

        tb.addView(toolBtn("\u25C0", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (bweb != null && bweb.canGoBack()) bweb.goBack();
            }
        }));
        tb.addView(toolBtn("\u25B6", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (bweb != null && bweb.canGoForward()) bweb.goForward();
            }
        }));
        tb.addView(toolBtn("\u27F3", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (bweb != null) bweb.reload();
            }
        }));

        urlEdit = new EditText(this);
        urlEdit.setSingleLine(true);
        urlEdit.setTextSize(12f);
        urlEdit.setTextColor(0xFFFFFFFF);
        urlEdit.setHintTextColor(0xFF777777);
        urlEdit.setHint("Cari atau ketik alamat");
        urlEdit.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        urlEdit.setImeOptions(EditorInfo.IME_ACTION_GO);
        GradientDrawable eb = new GradientDrawable();
        eb.setColor(0xFF141414);
        eb.setCornerRadius(dp(14));
        eb.setStroke(dp(1), 0xFF2A2A2A);
        urlEdit.setBackground(eb);
        urlEdit.setPadding(dp(10), 0, dp(10), 0);
        urlEdit.setLayoutParams(new LinearLayout.LayoutParams(0, dp(30), 1f));
        urlEdit.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                setPanelFocusable(hasFocus);
            }
        });
        urlEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setPanelFocusable(true);
            }
        });
        urlEdit.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                goUrl(urlEdit.getText().toString());
                return true;
            }
        });
        tb.addView(urlEdit);

        tb.addView(toolBtn("\u2715", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeBrowser();
            }
        }));
        browserBox.addView(tb, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, toolbarH));

        bweb = new WebView(new ContextThemeWrapper(getApplicationContext(), R.style.Theme_Alfred));
        WebSettings s = bweb.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setSupportMultipleWindows(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        bweb.setBackgroundColor(0xFFFFFFFF);
        try {
            CookieManager.getInstance().setAcceptCookie(true);
            CookieManager.getInstance().setAcceptThirdPartyCookies(bweb, true);
        } catch (Exception ignored) {
        }
        bweb.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                if (customView != null || panel == null) {
                    callback.onCustomViewHidden();
                    return;
                }
                customView = view;
                customCb = callback;
                panel.addView(view, new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
            }

            @Override
            public void onHideCustomView() {
                hideCustomView();
            }

            @Override
            public void onPermissionRequest(android.webkit.PermissionRequest request) {
                request.deny();
            }
        });
        bweb.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String sc = u.getScheme();
                if ("alfred".equals(sc)) {
                    if ("retry".equals(u.getHost())) {
                        loadToken++;
                        view.loadUrl(lastUrl);
                    } else if ("open".equals(u.getHost())) {
                        try {
                            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(lastUrl));
                            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(i);
                        } catch (Exception ignored) {
                        }
                    }
                    return true;
                }
                return !("http".equals(sc) || "https".equals(sc));
            }

            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                if (url != null && url.startsWith("http")) lastUrl = url;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (urlEdit != null && !urlEdit.hasFocus() && url != null && url.startsWith("http")) {
                    urlEdit.setText(url);
                }
                if (desktopMode) fitDesktop(view);
                scheduleBlankCheck(url);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    showErrorPage(String.valueOf(error.getDescription()));
                }
            }
        });
        browserBox.addView(bweb, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        browserBox.setVisibility(View.GONE);
        col.addView(browserBox, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
    }

    /** Situs desktop (mis. WhatsApp Web) diskalakan supaya muat lebar panel. */
    private void fitDesktop(WebView v) {
        try {
            float wDp = v.getWidth() / getResources().getDisplayMetrics().density;
            if (wDp <= 0) return;
            float vw = 720f;
            float scale = wDp / vw;
            String js = "(function(){var m=document.querySelector('meta[name=viewport]');if(!m){m=document.createElement('meta');m.name='viewport';document.head.appendChild(m);}"
                    + "m.content='width=" + (int) vw + ", initial-scale=" + scale + ", minimum-scale=0.2, user-scalable=yes';})()";
            v.evaluateJavascript(js, null);
        } catch (Throwable ignored) {
        }
    }

    private void scheduleBlankCheck(final String url) {
        if (bweb == null || url == null || !url.startsWith("http")) return;
        final int token = ++loadToken;
        bweb.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!browserShown || bweb == null || token != loadToken) return;
                bweb.evaluateJavascript("(function(){var b=document.body;return b?((b.innerText||'').trim().length+'|'+document.documentElement.scrollHeight):'0|0'})()",
                        new android.webkit.ValueCallback<String>() {
                            @Override
                            public void onReceiveValue(String v) {
                                try {
                                    String t = v == null ? "" : v.replace("\"", "");
                                    String[] a = t.split("\\|");
                                    int len = Integer.parseInt(a[0]);
                                    if (len < 12 && token == loadToken && browserShown) {
                                        showErrorPage("Halaman tampak kosong. Situs ini mungkin tidak mendukung jendela mini (mis. butuh DRM/aplikasi asli).");
                                    }
                                } catch (Throwable ignored) {
                                }
                            }
                        });
            }
        }, 7000);
    }

    private void showErrorPage(String msg) {
        if (bweb == null) return;
        String safe = msg == null ? "" : msg.replace("<", "&lt;");
        String html = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head>"
                + "<body style='margin:0;padding:18px;background:#0b0b0b;color:#eee;font-family:sans-serif;text-align:center'>"
                + "<div style='font-size:34px;margin-top:20px'>\uD83D\uDE15</div><h3>Tidak bisa ditampilkan</h3>"
                + "<p style='color:#aaa;font-size:13px;line-height:1.5'>" + safe + "</p>"
                + "<p><a href='alfred://retry' style='display:inline-block;margin:6px;padding:10px 16px;border-radius:20px;background:#fff;color:#000;text-decoration:none;font-weight:700'>Coba lagi</a>"
                + "<a href='alfred://open' style='display:inline-block;margin:6px;padding:10px 16px;border-radius:20px;background:#222;color:#fff;text-decoration:none;font-weight:700'>Buka di browser HP</a></p></body></html>";
        bweb.loadDataWithBaseURL("alfred://page", html, "text/html", "utf-8", null);
    }

    private void goUrl(String q) {
        if (bweb == null) return;
        q = q == null ? "" : q.trim();
        if (q.length() == 0) return;
        String url;
        if (q.startsWith("http://") || q.startsWith("https://")) {
            url = q;
        } else if (q.indexOf(' ') < 0 && q.indexOf('.') > 0) {
            url = "https://" + q;
        } else {
            url = "https://www.google.com/search?q=" + Uri.encode(q);
        }
        hideIme();
        if (urlEdit != null) urlEdit.clearFocus();
        bweb.loadUrl(url);
    }

    private void openBrowser(String url, boolean desktop) {
        ensurePanel();
        showPanel();
        if (browserBox == null) buildBrowser();
        desktopMode = desktop;
        WebSettings st = bweb.getSettings();
        if (desktop) {
            st.setUserAgentString(DESKTOP_UA);
        } else {
            st.setUserAgentString(null);
            String ua = st.getUserAgentString();
            if (ua != null) st.setUserAgentString(ua.replace("; wv", "").replace(" Version/4.0", ""));
        }
        browserShown = true;
        web.setVisibility(View.GONE);
        browserBox.setVisibility(View.VISIBLE);
        lastUrl = url;
        if (urlEdit != null) urlEdit.setText(url);
        loadWhenReady(url);
    }

    /** Memuat halaman setelah ukuran WebView diketahui, supaya skala halaman pas dengan panel. */
    private void loadWhenReady(final String url) {
        if (bweb.getWidth() > 0 && bweb.isShown()) {
            bweb.loadUrl(url);
            return;
        }
        bweb.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
            @Override
            public void onLayoutChange(View v, int l, int t, int r, int b, int ol, int ot, int or, int ob) {
                if (v.getWidth() > 0) {
                    v.removeOnLayoutChangeListener(this);
                    bweb.loadUrl(url);
                }
            }
        });
    }

    private void closeBrowser() {
        browserShown = false;
        loadToken++;
        hideCustomView();
        hideIme();
        if (urlEdit != null) urlEdit.clearFocus();
        try {
            CookieManager.getInstance().flush();
        } catch (Exception ignored) {
        }
        if (browserBox != null) browserBox.setVisibility(View.GONE);
        if (bweb != null) bweb.loadUrl("about:blank");
        if (web != null) web.setVisibility(View.VISIBLE);
    }

    // -------------------------------------------------- jembatan JS -> native

    public class PanelBridge {
        @JavascriptInterface
        public void close() {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    hidePanel();
                }
            });
        }

        @JavascriptInterface
        public void openApp() {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    hidePanel();
                    try {
                        Intent i = new Intent(OverlayService.this, MainActivity.class);
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                        startActivity(i);
                    } catch (Exception ignored) {
                    }
                }
            });
        }

        @JavascriptInterface
        public int accessState() {
            return AlfredAccessService.isRunning() ? 1 : 0;
        }

        @JavascriptInterface
        public void copy(final String text) {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    try {
                        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("Alfred AI", text == null ? "" : text));
                    } catch (Exception ignored) {
                    }
                }
            });
        }

        @JavascriptInterface
        public void openAccess() {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    try {
                        Intent i = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(i);
                    } catch (Exception ignored) {
                    }
                }
            });
        }

        @JavascriptInterface
        public void ready() {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    markReady();
                }
            });
        }

        @JavascriptInterface
        public void focusInput(boolean f) {
            setPanelFocusable(f);
        }

        @JavascriptInterface
        public String apps() {
            return prefs.getString("apps_json", "[]");
        }

        @JavascriptInterface
        public void refreshApps() {
            refreshAppsAsync();
        }

        @JavascriptInterface
        public void launch(final String pkg) {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    launchApp(pkg);
                }
            });
        }

        @JavascriptInterface
        public String sys() {
            return SysTools.sysJson(OverlayService.this);
        }

        @JavascriptInterface
        public String act(String a, String v) {
            return SysTools.act(OverlayService.this, a, v);
        }

        @JavascriptInterface
        public String vpn() {
            return SysTools.vpnJson(OverlayService.this);
        }

        @JavascriptInterface
        public void ping(String host, int port, int n) {
            SysTools.ping(host, port, n, new SysTools.Cb() {
                @Override
                public void done(String json) {
                    runJs("window.alfredPing && window.alfredPing(" + quote(json) + ")");
                }
            });
        }

        @JavascriptInterface
        public void noDrag(boolean b) {
            jsNoDrag = b;
        }

        @JavascriptInterface
        public void setZones(String json) {
            try {
                JSONArray a = new JSONArray(json);
                float[][] z = new float[a.length()][];
                char[] m = new char[a.length()];
                for (int i = 0; i < a.length(); i++) {
                    JSONObject o = a.getJSONObject(i);
                    z[i] = new float[]{(float) o.getDouble("x"), (float) o.getDouble("y"),
                            (float) o.getDouble("w"), (float) o.getDouble("h")};
                    String mm = o.optString("m", "n");
                    m[i] = mm.length() > 0 ? mm.charAt(0) : 'n';
                }
                zones = z;
                zoneModes = m;
            } catch (Exception ignored) {
            }
        }
    }
}
