package com.alfredai.app;

import android.Manifest;
import android.accounts.AccountManager;
import android.app.Activity;
import android.app.NotificationManager;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import org.json.JSONObject;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {

    static final int REQ_ACCOUNT = 101;
    static final int REQ_PICK = 102;
    static final int REQ_VOICE = 103;
    static final int REQ_CAMERA = 104;

    static final int RP_MIC = 201;
    static final int RP_NOTIF = 202;
    static final int RP_CAM = 203;

    static final long MAX_BYTES = 40L * 1024L * 1024L;
    static final int SMALL_IMAGE = 4 * 1024 * 1024;

    private WebView webView;
    private SharedPreferences prefs;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private String pendingSpeak = null;
    private File cameraFile = null;
    private final Handler ui = new Handler(Looper.getMainLooper());

    // ================================================================ lifecycle

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("alfred", MODE_PRIVATE);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMediaPlaybackRequiresUserGesture(false);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String sch = u.getScheme();
                if (sch == null || sch.equals("file") || sch.equals("about") || sch.equals("data")
                        || sch.equals("blob") || sch.equals("javascript")) {
                    return false;
                }
                try {
                    Intent i = new Intent(Intent.ACTION_VIEW, u);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                } catch (Exception ignored) {
                }
                return true;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            request.grant(request.getResources());
                        } catch (Exception ignored) {
                        }
                    }
                });
            }
        });
        webView.addJavascriptInterface(new Bridge(), "AlfredNative");
        webView.loadUrl("file:///android_asset/index.html");

        if (prefs.getBoolean("overlay_on", false) && Settings.canDrawOverlays(this)) {
            startOverlay();
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (tts != null) {
            try {
                tts.stop();
                tts.shutdown();
            } catch (Exception ignored) {
            }
            tts = null;
        }
        if (webView != null) {
            try {
                webView.destroy();
            } catch (Exception ignored) {
            }
            webView = null;
        }
        super.onDestroy();
    }

    // ================================================================ helpers

    private void js(final String code) {
        ui.post(new Runnable() {
            @Override
            public void run() {
                if (webView != null) webView.evaluateJavascript(code, null);
            }
        });
    }

    private static String quote(String s) {
        return JSONObject.quote(s == null ? "" : s).replace("\u2028", "\\u2028").replace("\u2029", "\\u2029");
    }

    private void toast(final String msg) {
        ui.post(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show();
            }
        });
    }

    private void jsToast(String msg, String kind) {
        js("try{showToast(" + quote(msg) + "," + quote(kind) + ")}catch(e){}");
    }

    private boolean has(String perm) {
        return Build.VERSION.SDK_INT < 23 || checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED;
    }

    private void openAppSettings() {
        try {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            i.setData(Uri.parse("package:" + getPackageName()));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception ignored) {
        }
    }

    private void startOverlay() {
        try {
            Intent i = new Intent(this, OverlayService.class);
            if (Build.VERSION.SDK_INT >= 26) {
                startForegroundService(i);
            } else {
                startService(i);
            }
        } catch (Exception e) {
            toast("Gagal mengaktifkan bulatan galaxy");
        }
    }

    private void stopOverlay() {
        try {
            stopService(new Intent(this, OverlayService.class));
        } catch (Exception ignored) {
        }
    }

    /** Meminta izin runtime; jika sudah ditolak permanen, buka Info Aplikasi. */
    private void askRuntime(String perm, String askedKey, int reqCode) {
        if (Build.VERSION.SDK_INT < 23) return;
        boolean asked = prefs.getBoolean(askedKey, false);
        boolean rationale = shouldShowRequestPermissionRationale(perm);
        if (asked && !rationale && !has(perm)) {
            openAppSettings();
            return;
        }
        prefs.edit().putBoolean(askedKey, true).apply();
        requestPermissions(new String[]{perm}, reqCode);
    }

    // ============================================================ TTS helpers

    private void speakText(final String text) {
        ui.post(new Runnable() {
            @Override
            public void run() {
                if (tts == null) {
                    pendingSpeak = text;
                    tts = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
                        @Override
                        public void onInit(int status) {
                            if (status == TextToSpeech.SUCCESS && tts != null) {
                                ttsReady = true;
                                int r = tts.setLanguage(new Locale("id", "ID"));
                                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                                    tts.setLanguage(Locale.getDefault());
                                }
                                if (pendingSpeak != null) {
                                    String t = pendingSpeak;
                                    pendingSpeak = null;
                                    doSpeak(t);
                                }
                            }
                        }
                    });
                    return;
                }
                if (!ttsReady) {
                    pendingSpeak = text;
                    return;
                }
                doSpeak(text);
            }
        });
    }

    private void doSpeak(String text) {
        if (tts == null || text == null) return;
        int max = 3500;
        int idx = 0;
        int part = 0;
        while (idx < text.length()) {
            int end = Math.min(text.length(), idx + max);
            String chunk = text.substring(idx, end);
            tts.speak(chunk, part == 0 ? TextToSpeech.QUEUE_FLUSH : TextToSpeech.QUEUE_ADD, null, "alfred_tts" + part);
            idx = end;
            part++;
        }
    }

    // ============================================================ file helpers

    private String displayName(Uri uri) {
        String n = null;
        Cursor c = null;
        try {
            c = getContentResolver().query(uri, null, null, null, null);
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0) n = c.getString(i);
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        if (n == null || n.length() == 0) {
            String p = uri.getLastPathSegment();
            n = (p == null || p.length() == 0) ? "berkas" : p;
        }
        return n;
    }

    private static String guessMime(String name) {
        String n = name == null ? "" : name.toLowerCase(Locale.ROOT);
        if (n.endsWith(".png")) return "image/png";
        if (n.endsWith(".jpg") || n.endsWith(".jpeg")) return "image/jpeg";
        if (n.endsWith(".webp")) return "image/webp";
        if (n.endsWith(".gif")) return "image/gif";
        if (n.endsWith(".zip")) return "application/zip";
        if (n.endsWith(".json")) return "application/json";
        if (n.endsWith(".mp3")) return "audio/mpeg";
        if (n.endsWith(".m4a")) return "audio/mp4";
        if (n.endsWith(".wav")) return "audio/wav";
        if (n.endsWith(".txt") || n.endsWith(".md") || n.endsWith(".csv") || n.endsWith(".js")
                || n.endsWith(".py") || n.endsWith(".java") || n.endsWith(".kt") || n.endsWith(".swift")
                || n.endsWith(".css")) return "text/plain";
        if (n.endsWith(".html") || n.endsWith(".htm")) return "text/html";
        return "application/octet-stream";
    }

    private static byte[] readAll(InputStream in, long max) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream(64 * 1024);
        byte[] buf = new byte[32 * 1024];
        long total = 0;
        int r;
        while ((r = in.read(buf)) != -1) {
            total += r;
            if (total > max) return null;
            bos.write(buf, 0, r);
        }
        return bos.toByteArray();
    }

    /** Perkecil gambar besar (maks 1600 px) dan perbaiki rotasi EXIF. */
    private static byte[] shrinkImage(byte[] raw) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(raw, 0, raw.length, o);
            int sample = 1;
            while (o.outWidth / sample > 3200 || o.outHeight / sample > 3200) sample *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            Bitmap bmp = BitmapFactory.decodeByteArray(raw, 0, raw.length, o2);
            if (bmp == null) return raw;

            int rotation = 0;
            try {
                ExifInterface ex = new ExifInterface(new ByteArrayInputStream(raw));
                int ori = ex.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                if (ori == ExifInterface.ORIENTATION_ROTATE_90) rotation = 90;
                else if (ori == ExifInterface.ORIENTATION_ROTATE_180) rotation = 180;
                else if (ori == ExifInterface.ORIENTATION_ROTATE_270) rotation = 270;
            } catch (Exception ignored) {
            }

            int w = bmp.getWidth();
            int h = bmp.getHeight();
            float scale = Math.min(1f, 1600f / Math.max(w, h));
            Matrix m = new Matrix();
            if (scale < 1f) m.postScale(scale, scale);
            if (rotation != 0) m.postRotate(rotation);
            Bitmap out = bmp;
            if (scale < 1f || rotation != 0) {
                out = Bitmap.createBitmap(bmp, 0, 0, w, h, m, true);
            }
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            out.compress(Bitmap.CompressFormat.JPEG, 85, bos);
            return bos.toByteArray();
        } catch (Throwable t) {
            return raw;
        }
    }

    /** Membuat item lampiran sesuai format yang diharapkan window.onAlfredAttachment. */
    private JSONObject buildItem(Uri uri, String forcedName) throws Exception {
        String name = forcedName != null ? forcedName : displayName(uri);
        String mime = getContentResolver().getType(uri);
        if (mime == null || mime.length() == 0) mime = guessMime(name);
        InputStream in = getContentResolver().openInputStream(uri);
        if (in == null) throw new IOException("stream kosong");
        byte[] raw;
        try {
            raw = readAll(in, MAX_BYTES);
        } finally {
            in.close();
        }
        if (raw == null) return null;
        if (mime.startsWith("image/") && raw.length > SMALL_IMAGE) {
            raw = shrinkImage(raw);
            mime = "image/jpeg";
        }
        JSONObject o = new JSONObject();
        o.put("kind", "image");
        o.put("name", name);
        o.put("mime", mime);
        o.put("data", Base64.encodeToString(raw, Base64.NO_WRAP));
        return o;
    }

    private void deliver(final ArrayList<Uri> uris, final String forcedName) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < uris.size(); i++) {
                    try {
                        JSONObject o = buildItem(uris.get(i), forcedName);
                        if (o == null) {
                            jsToast("Berkas terlalu besar (maks 40 MB)", "error");
                            continue;
                        }
                        js("window.onAlfredAttachment(" + quote(o.toString()) + ")");
                    } catch (Exception e) {
                        jsToast("Gagal membaca berkas", "error");
                    }
                }
            }
        }).start();
    }

    private void launchCamera() {
        try {
            File dir = new File(getCacheDir(), "cam");
            if (!dir.exists()) dir.mkdirs();
            cameraFile = new File(dir, "kamera.jpg");
            Uri out = FileProvider.getUriForFile(this, getPackageName() + ".fp", cameraFile);
            Intent i = new Intent("android.media.action.IMAGE_CAPTURE");
            i.putExtra("output", out);
            i.setClipData(ClipData.newRawUri("", out));
            i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(i, REQ_CAMERA);
        } catch (Exception e) {
            jsToast("Kamera tidak bisa dibuka", "error");
        }
    }

    // ============================================================ results

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ_ACCOUNT) {
            if (resultCode == RESULT_OK && data != null) {
                String name = data.getStringExtra(AccountManager.KEY_ACCOUNT_NAME);
                if (name != null && name.length() > 0) {
                    prefs.edit().putString("account", name).apply();
                    js("window.onAlfredAccount(" + quote(name) + ")");
                } else {
                    js("window.onAlfredAccountFail()");
                }
            }
            return;
        }

        if (requestCode == REQ_PICK) {
            if (resultCode != RESULT_OK || data == null) return;
            ArrayList<Uri> uris = new ArrayList<Uri>();
            ClipData cd = data.getClipData();
            if (cd != null) {
                for (int i = 0; i < cd.getItemCount(); i++) {
                    Uri u = cd.getItemAt(i).getUri();
                    if (u != null) uris.add(u);
                }
            } else if (data.getData() != null) {
                uris.add(data.getData());
            }
            if (!uris.isEmpty()) deliver(uris, null);
            return;
        }

        if (requestCode == REQ_CAMERA) {
            if (resultCode == RESULT_OK && cameraFile != null && cameraFile.exists()) {
                ArrayList<Uri> uris = new ArrayList<Uri>();
                uris.add(Uri.fromFile(cameraFile));
                deliver(uris, "kamera.jpg");
            }
            return;
        }

        if (requestCode == REQ_VOICE) {
            String text = "";
            if (resultCode == RESULT_OK && data != null) {
                ArrayList<String> r = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                if (r != null && !r.isEmpty()) text = r.get(0);
            }
            js("window.onAlfredVoice(" + quote(text) + ")");
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == RP_CAM) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                launchCamera();
            } else {
                jsToast("Izin kamera ditolak", "error");
            }
        }
        // RP_MIC dan RP_NOTIF: status dibaca ulang oleh halaman (polling).
    }

    // ============================================================ JS bridge

    public class Bridge {

        // ---------- akun Google ----------

        @JavascriptInterface
        public String getAccount() {
            return prefs.getString("account", "");
        }

        @JavascriptInterface
        public void saveAccount(String account) {
            prefs.edit().putString("account", account == null ? "" : account).apply();
        }

        @SuppressWarnings("deprecation")
        @JavascriptInterface
        public void linkGoogle() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Intent i = AccountManager.newChooseAccountIntent(
                                null, null, new String[]{"com.google"}, false, null, null, null, null);
                        startActivityForResult(i, REQ_ACCOUNT);
                    } catch (Throwable t) {
                        js("window.onAlfredAccountFail()");
                    }
                }
            });
        }

        // ---------- suara ----------

        @JavascriptInterface
        public void speak(String text) {
            speakText(text);
        }

        @JavascriptInterface
        public void stopSpeak() {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    if (tts != null) {
                        try {
                            tts.stop();
                        } catch (Exception ignored) {
                        }
                    }
                }
            });
        }

        @JavascriptInterface
        public void startVoice() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID");
                        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Silakan bicara...");
                        startActivityForResult(i, REQ_VOICE);
                    } catch (ActivityNotFoundException e) {
                        toast("Pengenal suara tidak tersedia di HP ini");
                        js("window.onAlfredVoice('')");
                    } catch (Exception e) {
                        js("window.onAlfredVoice('')");
                    }
                }
            });
        }

        // ---------- berkas ----------

        @JavascriptInterface
        public void pick(final String kind) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        if ("camera".equals(kind)) {
                            if (!has(Manifest.permission.CAMERA)) {
                                requestPermissions(new String[]{Manifest.permission.CAMERA}, RP_CAM);
                            } else {
                                launchCamera();
                            }
                            return;
                        }
                        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                        i.addCategory(Intent.CATEGORY_OPENABLE);
                        i.setType("image".equals(kind) ? "image/*" : "*/*");
                        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                        startActivityForResult(i, REQ_PICK);
                    } catch (Exception e) {
                        jsToast("Gagal membuka pemilih berkas", "error");
                    }
                }
            });
        }

        // ---------- notifikasi ----------

        @JavascriptInterface
        public void showNotification(String title, String body) {
            Notifier.show(MainActivity.this, title, body, (int) (System.currentTimeMillis() % 100000L) + 1000);
        }

        @JavascriptInterface
        public void schedNotif(int id, String payload) {
            if (payload == null) return;
            String[] p = payload.split("\u0001", -1);
            if (p.length < 3) return;
            try {
                long ms = Long.parseLong(p[0].trim());
                Sched.add(MainActivity.this, id, ms, p[1], p[2]);
            } catch (Exception ignored) {
            }
        }

        @JavascriptInterface
        public void cancelNotifs() {
            Sched.cancelAll(MainActivity.this);
        }

        /** 1 = notifikasi diizinkan, 0 = belum. */
        @JavascriptInterface
        public int notifState() {
            try {
                NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                return (nm != null && nm.areNotificationsEnabled()) ? 1 : 0;
            } catch (Exception e) {
                return 1;
            }
        }

        @JavascriptInterface
        public void askNotifications() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (Build.VERSION.SDK_INT >= 33) {
                        askRuntime(Manifest.permission.POST_NOTIFICATIONS, "asked_notif", RP_NOTIF);
                    } else {
                        try {
                            Intent i;
                            if (Build.VERSION.SDK_INT >= 26) {
                                i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
                                i.putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
                            } else {
                                i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                                i.setData(Uri.parse("package:" + getPackageName()));
                            }
                            startActivity(i);
                        } catch (Exception ignored) {
                        }
                    }
                }
            });
        }

        // ---------- mikrofon ----------

        /** 1 = mikrofon diizinkan, 0 = belum. */
        @JavascriptInterface
        public int micState() {
            return has(Manifest.permission.RECORD_AUDIO) ? 1 : 0;
        }

        @JavascriptInterface
        public void askMic() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    askRuntime(Manifest.permission.RECORD_AUDIO, "asked_mic", RP_MIC);
                }
            });
        }

        // ---------- tampilkan atas aplikasi lain ----------

        /** 1 = izin "tampil di atas aplikasi lain" aktif, 0 = belum. */
        @JavascriptInterface
        public int overlayState() {
            return Settings.canDrawOverlays(MainActivity.this) ? 1 : 0;
        }

        @JavascriptInterface
        public void askOverlay() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:" + getPackageName()));
                        startActivity(i);
                    } catch (Exception e) {
                        openAppSettings();
                    }
                }
            });
        }

        /** 1 = fitur bulatan sedang dinyalakan, 0 = mati. */
        @JavascriptInterface
        public int overlayOn() {
            return (prefs.getBoolean("overlay_on", false) && Settings.canDrawOverlays(MainActivity.this)) ? 1 : 0;
        }

        @JavascriptInterface
        public void setOverlay(final boolean on) {
            prefs.edit().putBoolean("overlay_on", on).apply();
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (on && Settings.canDrawOverlays(MainActivity.this)) {
                        startOverlay();
                    } else {
                        stopOverlay();
                    }
                }
            });
        }

        // ---------- aksesibilitas (membaca tulisan di aplikasi lain) ----------

        @JavascriptInterface
        public int accessState() {
            return AlfredAccessService.isRunning() ? 1 : 0;
        }

        @JavascriptInterface
        public void openAccess() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                    } catch (Exception ignored) {
                    }
                }
            });
        }

        // ---------- keyboard, VPN & jaringan ----------

        @JavascriptInterface
        public void showKeyboard() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        if (webView == null) return;
                        webView.requestFocus();
                        InputMethodManager m = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                        if (m != null) m.showSoftInput(webView, 0);
                    } catch (Exception ignored) {
                    }
                }
            });
        }

        @JavascriptInterface
        public String vpnJson() {
            return SysTools.vpnJson(MainActivity.this);
        }

        @JavascriptInterface
        public String sysJson() {
            return SysTools.sysJson(MainActivity.this);
        }

        @JavascriptInterface
        public String act(String a, String v) {
            return SysTools.act(MainActivity.this, a, v);
        }

        @JavascriptInterface
        public void ping(String host, int port, int n) {
            SysTools.ping(host, port, n, new SysTools.Cb() {
                @Override
                public void done(String json) {
                    js("window.alfredPing && window.alfredPing(" + quote(json) + ")");
                }
            });
        }
    }
}
