package com.alfredai.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;

/** Penjadwal notifikasi harian (disimpan di SharedPreferences supaya bisa dipasang ulang setelah reboot). */
final class Sched {
    private static final String PREF = "alfred_sched";
    private static final String KEY = "plan";
    private static final int REQ_BASE = 70000;

    private Sched() {}

    private static SharedPreferences sp(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    private static JSONArray load(Context c) {
        try {
            return new JSONArray(sp(c).getString(KEY, "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    private static void save(Context c, JSONArray a) {
        sp(c).edit().putString(KEY, a.toString()).apply();
    }

    private static PendingIntent pending(Context c, int id, String title, String body, int flags) {
        Intent i = new Intent(c, AlarmRx.class);
        i.putExtra("id", id);
        i.putExtra("title", title);
        i.putExtra("body", body);
        return PendingIntent.getBroadcast(c, REQ_BASE + id, i, flags | PendingIntent.FLAG_IMMUTABLE);
    }

    private static void arm(Context c, int id, long ms, String title, String body) {
        try {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;
            PendingIntent pi = pending(c, id, title, body, PendingIntent.FLAG_UPDATE_CURRENT);
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, pi);
        } catch (Exception ignored) {
        }
    }

    private static void disarm(Context c, int id) {
        try {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;
            PendingIntent pi = pending(c, id, "", "", PendingIntent.FLAG_NO_CREATE);
            if (pi != null) {
                am.cancel(pi);
                pi.cancel();
            }
        } catch (Exception ignored) {
        }
    }

    static synchronized void add(Context c, int id, long ms, String title, String body) {
        try {
            JSONArray old = load(c);
            JSONArray n = new JSONArray();
            for (int i = 0; i < old.length(); i++) {
                JSONObject o = old.optJSONObject(i);
                if (o != null && o.optInt("id", -1) != id) n.put(o);
            }
            JSONObject o = new JSONObject();
            o.put("id", id);
            o.put("ms", ms);
            o.put("title", title);
            o.put("body", body);
            n.put(o);
            save(c, n);
        } catch (Exception ignored) {
        }
        arm(c, id, ms, title, body);
    }

    static synchronized void cancelAll(Context c) {
        JSONArray a = load(c);
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null) disarm(c, o.optInt("id", -1));
        }
        save(c, new JSONArray());
    }

    static synchronized void fired(Context c, int id) {
        JSONArray old = load(c);
        JSONArray n = new JSONArray();
        for (int i = 0; i < old.length(); i++) {
            JSONObject o = old.optJSONObject(i);
            if (o != null && o.optInt("id", -1) != id) n.put(o);
        }
        save(c, n);
    }

    static synchronized void rearm(Context c) {
        JSONArray old = load(c);
        JSONArray keep = new JSONArray();
        long now = System.currentTimeMillis();
        for (int i = 0; i < old.length(); i++) {
            JSONObject o = old.optJSONObject(i);
            if (o == null) continue;
            long ms = o.optLong("ms", 0L);
            if (ms > now) {
                keep.put(o);
                arm(c, o.optInt("id", -1), ms, o.optString("title", "Alfred AI"), o.optString("body", ""));
            }
        }
        save(c, keep);
    }
}
