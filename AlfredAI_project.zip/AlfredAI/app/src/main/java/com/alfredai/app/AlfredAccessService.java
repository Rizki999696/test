package com.alfredai.app;

import android.accessibilityservice.AccessibilityService;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.hardware.HardwareBuffer;
import android.os.Build;
import android.view.Display;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.util.List;

/**
 * Membaca tulisan di titik layar tertentu (dipakai kaca pembesar).
 * 1) Dari pohon aksesibilitas (cepat, akurat) untuk aplikasi biasa.
 * 2) Jika tidak ada teks (mis. game), dari tangkapan layar + OCR di perangkat (Android 11+), tanpa API key.
 * Kolom kata sandi dilewati. Hanya dipanggil saat kaca pembesar dilepas di atas tulisan.
 */
public class AlfredAccessService extends AccessibilityService {

    public interface OcrCallback {
        void onResult(String text, String err);
    }

    private static AlfredAccessService instance;

    static boolean isRunning() {
        return instance != null;
    }

    /** Teks dari pohon aksesibilitas (tanpa OCR). Null jika tidak ada. */
    static String textAtTree(int x, int y) {
        AlfredAccessService s = instance;
        if (s == null) return null;
        try {
            return s.findText(x, y);
        } catch (Throwable t) {
            return null;
        }
    }

    /** Teks dari tangkapan layar + OCR. Callback selalu dipanggil sekali (di thread utama). */
    static void ocrAt(int x, int y, OcrCallback cb) {
        AlfredAccessService s = instance;
        if (s == null) {
            cb.onResult(null, "Layanan aksesibilitas belum aktif.");
            return;
        }
        if (Build.VERSION.SDK_INT < 30) {
            cb.onResult(null, "Membaca teks game butuh Android 11 atau lebih baru.");
            return;
        }
        s.doOcr(x, y, cb);
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // tidak dipakai
    }

    @Override
    public void onInterrupt() {
        // tidak dipakai
    }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        instance = null;
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        instance = null;
        super.onDestroy();
    }

    // ------------------------------------------------------------- OCR

    private void doOcr(final int x, final int y, final OcrCallback cb) {
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(), new TakeScreenshotCallback() {
                @Override
                public void onSuccess(ScreenshotResult r) {
                    try {
                        HardwareBuffer hb = r.getHardwareBuffer();
                        Bitmap hw = Bitmap.wrapHardwareBuffer(hb, r.getColorSpace());
                        if (hw == null) {
                            hb.close();
                            cb.onResult(null, "Gagal membaca tangkapan layar.");
                            return;
                        }
                        Bitmap soft = hw.copy(Bitmap.Config.ARGB_8888, false);
                        hb.close();
                        if (soft == null) {
                            cb.onResult(null, "Memori tidak cukup untuk membaca layar.");
                            return;
                        }
                        recognize(soft, x, y, cb);
                    } catch (Throwable t) {
                        cb.onResult(null, "Gagal memproses layar.");
                    }
                }

                @Override
                public void onFailure(int code) {
                    if (code == 3) {
                        cb.onResult(null, "Tunggu sebentar lalu coba lagi.");
                    } else {
                        cb.onResult(null, "Aplikasi ini memblokir tangkapan layar (kode " + code + ").");
                    }
                }
            });
        } catch (Throwable t) {
            cb.onResult(null, "Pembaca layar tidak tersedia di perangkat ini.");
        }
    }

    private void recognize(final Bitmap full, final int x, final int y, final OcrCallback cb) {
        try {
            final float d = getResources().getDisplayMetrics().density;
            int hw = (int) (180 * d);
            int hh = (int) (90 * d);
            int left = Math.max(0, x - hw);
            int top = Math.max(0, y - hh);
            int right = Math.min(full.getWidth(), x + hw);
            int bottom = Math.min(full.getHeight(), y + hh);
            if (right - left < 8 || bottom - top < 8) {
                cb.onResult(null, "Titik berada di luar layar.");
                return;
            }
            final int ox = left;
            final int oy = top;
            Bitmap crop = Bitmap.createBitmap(full, left, top, right - left, bottom - top);
            TextRecognizer rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
            InputImage img = InputImage.fromBitmap(crop, 0);
            rec.process(img).addOnSuccessListener(new OnSuccessListener<Text>() {
                @Override
                public void onSuccess(Text t) {
                    Text.TextBlock best = null;
                    double bd = Double.MAX_VALUE;
                    for (Text.TextBlock b : t.getTextBlocks()) {
                        for (Text.Line l : b.getLines()) {
                            Rect r0 = l.getBoundingBox();
                            if (r0 == null) continue;
                            Rect r = new Rect(r0);
                            r.offset(ox, oy);
                            int dx = Math.max(Math.max(r.left - x, 0), x - r.right);
                            int dy = Math.max(Math.max(r.top - y, 0), y - r.bottom);
                            double dist = Math.sqrt((double) dx * dx + (double) dy * dy);
                            if (dist < bd) {
                                bd = dist;
                                best = b;
                            }
                        }
                    }
                    if (best != null && bd <= 60 * d) {
                        String s = best.getText().replace("\n", " ").trim();
                        if (s.length() > 2000) s = s.substring(0, 2000);
                        cb.onResult(s, null);
                    } else {
                        cb.onResult(null, "Tidak ada tulisan terbaca di titik ini.");
                    }
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(Exception e) {
                    cb.onResult(null, "Pembaca teks gagal dijalankan.");
                }
            });
        } catch (Throwable t) {
            cb.onResult(null, "Gagal membaca tulisan.");
        }
    }

    // ------------------------------------------------- pohon aksesibilitas

    private static class Best {
        String inside = null;
        long insideArea = Long.MAX_VALUE;
        String near = null;
        double nearDist = Double.MAX_VALUE;
        int count = 0;
    }

    private String findText(int x, int y) {
        String self = getPackageName();
        int nearMax = (int) (90 * getResources().getDisplayMetrics().density);

        try {
            List<AccessibilityWindowInfo> ws = getWindows();
            if (ws != null) {
                Rect wr = new Rect();
                for (AccessibilityWindowInfo w : ws) {
                    AccessibilityNodeInfo root = w.getRoot();
                    if (root == null) continue;
                    CharSequence pkg = root.getPackageName();
                    if (pkg != null) {
                        String p = pkg.toString();
                        if (p.equals(self) || p.equals("com.android.systemui")) continue;
                    }
                    w.getBoundsInScreen(wr);
                    if (!wr.contains(x, y)) continue;
                    String t = search(root, x, y, nearMax);
                    if (t != null) return t;
                }
            }
        } catch (Throwable ignored) {
        }

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root != null) {
            CharSequence pkg = root.getPackageName();
            if (pkg == null || !pkg.toString().equals(self)) {
                return search(root, x, y, nearMax);
            }
        }
        return null;
    }

    private String search(AccessibilityNodeInfo root, int x, int y, int nearMax) {
        Best b = new Best();
        walk(root, x, y, b, 0);
        String res = b.inside;
        if (res == null && b.near != null && b.nearDist <= nearMax) res = b.near;
        if (res != null && res.length() > 2000) res = res.substring(0, 2000);
        return res;
    }

    private void walk(AccessibilityNodeInfo n, int x, int y, Best b, int depth) {
        if (n == null || depth > 70 || b.count > 6000) return;
        b.count++;
        if (depth > 0 && !n.isVisibleToUser()) return;

        Rect r = new Rect();
        n.getBoundsInScreen(r);

        if (!n.isPassword()) {
            CharSequence t = n.getText();
            if (t == null || t.toString().trim().length() == 0) t = n.getContentDescription();
            if (t != null) {
                String s = t.toString().trim();
                if (s.length() > 0) {
                    if (r.contains(x, y)) {
                        long area = (long) r.width() * (long) r.height();
                        if (area > 0 && area < b.insideArea) {
                            b.insideArea = area;
                            b.inside = s;
                        }
                    } else {
                        int dx = Math.max(Math.max(r.left - x, 0), x - r.right);
                        int dy = Math.max(Math.max(r.top - y, 0), y - r.bottom);
                        double d = Math.sqrt((double) dx * dx + (double) dy * dy);
                        if (d < b.nearDist) {
                            b.nearDist = d;
                            b.near = s;
                        }
                    }
                }
            }
        }

        int c = n.getChildCount();
        for (int i = 0; i < c; i++) {
            AccessibilityNodeInfo ch = n.getChild(i);
            if (ch != null) walk(ch, x, y, b, depth + 1);
        }
    }
}
